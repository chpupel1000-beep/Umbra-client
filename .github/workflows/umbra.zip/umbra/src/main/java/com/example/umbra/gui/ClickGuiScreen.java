package com.example.umbra.gui;

import com.example.umbra.UmbraMod;
import com.example.umbra.module.Category;
import com.example.umbra.module.Module;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.util.InputUtil;
import net.minecraft.text.Text;
import org.lwjgl.glfw.GLFW;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

/** Тёмное минималистичное меню: вкладки сверху, модули списком. ПКМ по модулю раскрывает его настройки. */
public class ClickGuiScreen extends Screen {
    private static final int BG = 0xF0090909;
    private static final int LINE = 0xFF1F1F1F;
    private static final int ROW = 0x0DFFFFFF;
    private static final int ROW_HOVER = 0x1CFFFFFF;
    private static final int ACCENT = 0xFFA78BFA;
    private static final int TEXT = 0xFFE5E7EB;
    private static final int DIM = 0xFF6B7280;

    private static final int ROW_H = 20;
    private static final int SUB_H = 15;

    private static Category selected = Category.COMBAT;
    private static final Set<Module> expanded = new HashSet<>();
    private double scroll = 0;

    private int px, py, pw, ph, listX, listY, listW, listH;

    public ClickGuiScreen() {
        super(Text.literal("Umbra"));
    }

    private void layout() {
        pw = Math.min(width - 16, 300);
        ph = Math.min(height - 16, 250);
        px = (width - pw) / 2;
        py = (height - ph) / 2;
        listX = px + 8;
        listY = py + 44;
        listW = pw - 16;
        listH = ph - 74;
    }

    /** Одна строка списка: модуль или его настройка. */
    private static final class Entry {
        Module module;
        Module.Setting setting; // null = строка модуля или строка режима
        boolean modeRow;
        int y, h;
    }

    private List<Entry> entries() {
        List<Entry> out = new ArrayList<>();
        int y = 0;
        for (Module m : UmbraMod.MODULES.getModules()) {
            if (m.getCategory() != selected) continue;
            Entry e = new Entry();
            e.module = m;
            e.y = y;
            e.h = ROW_H;
            out.add(e);
            y += ROW_H + 2;
            if (expanded.contains(m)) {
                for (Module.Setting s : m.getSettings()) {
                    Entry se = new Entry();
                    se.module = m;
                    se.setting = s;
                    se.y = y;
                    se.h = SUB_H;
                    out.add(se);
                    y += SUB_H;
                }
                if (m.getSettings().isEmpty() && !m.getModes().isEmpty()) {
                    Entry me = new Entry();
                    me.module = m;
                    me.modeRow = true;
                    me.y = y;
                    me.h = SUB_H;
                    out.add(me);
                    y += SUB_H;
                }
                y += 3;
            }
        }
        return out;
    }

    private static boolean expandable(Module m) {
        return !m.getSettings().isEmpty() || !m.getModes().isEmpty();
    }

    private static boolean inside(double mx, double my, int x, int y, int w, int h) {
        return mx >= x && mx < x + w && my >= y && my < y + h;
    }

    private int tabX(int index) {
        int x = px + 10;
        Category[] cats = Category.values();
        for (int i = 0; i < index; i++) x += textRenderer.getWidth(cats[i].title) + 14;
        return x;
    }

    @Override
    public void renderBackground(DrawContext c, int mx, int my, float delta) {
        c.fill(0, 0, width, height, 0xA0000000);
    }

    @Override
    public void render(DrawContext c, int mx, int my, float delta) {
        super.render(c, mx, my, delta);
        layout();

        c.fill(px, py, px + pw, py + ph, BG);
        c.fill(px, py, px + pw, py + 1, ACCENT);
        c.fill(px, py + ph - 1, px + pw, py + ph, LINE);
        c.fill(px, py, px + 1, py + ph, LINE);
        c.fill(px + pw - 1, py, px + pw, py + ph, LINE);

        c.drawText(textRenderer, "UMBRA", px + 10, py + 9, ACCENT, false);
        String hint = "ПКМ — настройки";
        c.drawText(textRenderer, hint, px + pw - textRenderer.getWidth(hint) - 10, py + 9, DIM, false);

        // Вкладки
        Category[] cats = Category.values();
        for (int i = 0; i < cats.length; i++) {
            int x = tabX(i);
            int w = textRenderer.getWidth(cats[i].title);
            boolean sel = cats[i] == selected;
            boolean hov = inside(mx, my, x - 3, py + 22, w + 6, 16);
            c.drawText(textRenderer, cats[i].title, x, py + 27, sel ? TEXT : (hov ? 0xFF9CA3AF : DIM), false);
            if (sel) c.fill(x, py + 38, x + w, py + 39, ACCENT);
        }
        c.fill(px + 8, py + 40, px + pw - 8, py + 41, LINE);

        // Список модулей
        List<Entry> list = entries();
        int total = list.isEmpty() ? 0 : list.get(list.size() - 1).y + list.get(list.size() - 1).h;
        scroll = Math.max(0, Math.min(scroll, Math.max(0, total - listH)));
        c.enableScissor(listX, listY, listX + listW, listY + listH);
        if (list.isEmpty()) c.drawText(textRenderer, "Здесь пока пусто", listX, listY + 4, DIM, false);
        for (Entry e : list) {
            int y = listY + e.y - (int) scroll;
            boolean hov = inside(mx, my, listX, y, listW, e.h) && my >= listY && my < listY + listH;
            Module m = e.module;
            if (e.setting == null && !e.modeRow) {
                boolean on = m.isEnabled();
                c.fill(listX, y, listX + listW, y + e.h, hov ? ROW_HOVER : ROW);
                if (on) c.fill(listX, y, listX + 2, y + e.h, ACCENT);
                c.drawText(textRenderer, m.getName(), listX + 9, y + 6, on ? ACCENT : TEXT, false);
                if (m.key != GLFW.GLFW_KEY_UNKNOWN) {
                    String bind = "[" + InputUtil.fromKeyCode(m.key, 0).getLocalizedText().getString() + "]";
                    c.drawText(textRenderer, bind, listX + 14 + textRenderer.getWidth(m.getName()), y + 6, DIM, false);
                }
                int rx = listX + listW - 10;
                if (expandable(m)) {
                    String sign = expanded.contains(m) ? "-" : "+";
                    c.drawText(textRenderer, sign, rx - 14, y + 6, DIM, false);
                }
                // Переключатель: квадрат
                c.fill(rx - 1, y + 5, rx + 9, y + 15, on ? ACCENT : LINE);
                if (!on) c.fill(rx, y + 6, rx + 8, y + 14, BG);
            } else {
                String name = e.modeRow ? "Mode" : e.setting.name;
                String value = e.modeRow ? m.getModeName() : e.setting.value();
                if (hov) c.fill(listX + 9, y, listX + listW, y + e.h, ROW);
                c.fill(listX + 4, y, listX + 5, y + e.h, LINE);
                c.drawText(textRenderer, name, listX + 14, y + 4, DIM, false);
                String v = "‹ " + value + " ›";
                c.drawText(textRenderer, v, listX + listW - 8 - textRenderer.getWidth(v), y + 4, TEXT, false);
            }
        }
        c.disableScissor();

        // Нижняя панель
        int by = py + ph - 24;
        c.fill(px + 8, by - 3, px + pw - 8, by - 2, LINE);
        boolean hh = inside(mx, my, px + 8, by, 100, 16);
        c.drawText(textRenderer, "Позиции HUD", px + 10, by + 4, hh ? ACCENT : DIM, false);
        String close = "Esc — закрыть";
        c.drawText(textRenderer, close, px + pw - textRenderer.getWidth(close) - 10, by + 4, DIM, false);
    }

    @Override
    public boolean mouseClicked(double mx, double my, int button) {
        layout();

        if (button == 0) {
            Category[] cats = Category.values();
            for (int i = 0; i < cats.length; i++) {
                if (inside(mx, my, tabX(i) - 3, py + 22, textRenderer.getWidth(cats[i].title) + 6, 17)) {
                    selected = cats[i];
                    scroll = 0;
                    return true;
                }
            }
            if (inside(mx, my, px + 8, py + ph - 24, 100, 16)) {
                client.setScreen(new HudEditorScreen(this));
                return true;
            }
        }

        if ((button == 0 || button == 1) && inside(mx, my, listX, listY, listW, listH)) {
            for (Entry e : entries()) {
                int y = listY + e.y - (int) scroll;
                if (!inside(mx, my, listX, y, listW, e.h)) continue;
                Module m = e.module;
                int dir = button == 0 ? 1 : -1;
                if (e.setting != null) {
                    e.setting.cycle(dir);
                    UmbraMod.MODULES.save();
                } else if (e.modeRow) {
                    int n = m.getModes().size();
                    for (int i = 0; i < (dir > 0 ? 1 : Math.max(1, n - 1)); i++) m.cycleMode();
                    UmbraMod.MODULES.save();
                } else if (button == 0) {
                    m.toggle();
                } else if (expandable(m)) {
                    if (!expanded.remove(m)) expanded.add(m);
                }
                return true;
            }
        }
        return super.mouseClicked(mx, my, button);
    }

    @Override
    public boolean mouseScrolled(double mx, double my, double horizontal, double vertical) {
        scroll -= vertical * 14;
        return true;
    }

    @Override
    public boolean keyPressed(int keyCode, int scanCode, int modifiers) {
        if (keyCode == GLFW.GLFW_KEY_RIGHT_SHIFT) {
            close();
            return true;
        }
        return super.keyPressed(keyCode, scanCode, modifiers);
    }

    @Override
    public boolean shouldPause() { return false; }
}
