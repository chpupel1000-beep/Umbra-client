package com.example.umbra.module;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.world.ClientWorld;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.decoration.ArmorStandEntity;
import net.minecraft.particle.ParticleEffect;
import net.minecraft.particle.ParticleTypes;
import net.minecraft.text.Text;

import java.util.List;

/**
 * Эффект вокруг цели из частиц:
 *  Spirits: три светящихся духа летают вокруг цели,
 *  Square: квадрат ходит вверх-вниз по телу цели,
 *  Ring: кольцо скользит вверх-вниз вокруг цели.
 * Цель: та, что бьёт KillAura, иначе существо под прицелом,
 * иначе ближайшее живое существо (моб, животное или игрок) в радиусе 12 блоков.
 */
public class TargetHud extends Module {
    private static final String[] NAMES = {"Spirits", "Square", "Ring"};
    private static final double RANGE = 12.0;

    public TargetHud() {
        super("TargetHUD", "Эффект вокруг цели: духи, квадрат или кольцо", Category.VISUALS);
    }

    @Override
    public List<String> getModes() { return List.of(NAMES); }

    @Override
    public void onTick(MinecraftClient client) {
        ClientWorld world = client.world;
        if (client.player == null || world == null) return;

        LivingEntity e = findTarget(client);
        double t = world.getTime();
        if (e == null) {
            // Подсказка, чтобы было понятно, почему эффекта нет
            if (world.getTime() % 60 == 0) {
                client.player.sendMessage(Text.literal("TargetHUD: рядом нет цели"), true);
            }
            return;
        }

        double cx = e.getX(), cz = e.getZ(), base = e.getY();
        double r = e.getWidth() * 0.5 + 0.55;
        double h = e.getHeight();

        switch (Math.max(0, Math.min(mode, NAMES.length - 1))) {
            case 0 -> { // Spirits: яркие END_ROD, три духа
                for (int i = 0; i < 3; i++) {
                    double a = t * 0.3 + i * (Math.PI * 2.0 / 3.0);
                    double y = base + h * (0.5 + 0.4 * Math.sin(t * 0.17 + i * 2.1));
                    spawn(world, ParticleTypes.END_ROD, cx + Math.cos(a) * r, y, cz + Math.sin(a) * r);
                }
            }
            case 1 -> { // Square: квадрат без вращения, чтобы форма читалась
                double y = base + h * (0.5 + 0.45 * Math.sin(t * 0.1));
                for (int side = 0; side < 4; side++) {
                    double[] c1 = corner(side, r);
                    double[] c2 = corner(side + 1, r);
                    for (int k = 0; k < 3; k++) {
                        double f = k / 3.0;
                        spawn(world, ParticleTypes.ELECTRIC_SPARK,
                                cx + c1[0] + (c2[0] - c1[0]) * f, y, cz + c1[1] + (c2[1] - c1[1]) * f);
                    }
                }
            }
            default -> { // Ring
                double y = base + h * (0.5 + 0.5 * Math.sin(t * 0.12));
                for (int i = 0; i < 12; i++) {
                    double a = i * (Math.PI * 2.0 / 12.0);
                    spawn(world, ParticleTypes.ELECTRIC_SPARK, cx + Math.cos(a) * r, y, cz + Math.sin(a) * r);
                }
            }
        }
    }

    // «Важные» частицы появляются даже при минимальных настройках частиц в игре
    private static void spawn(ClientWorld world, ParticleEffect effect, double x, double y, double z) {
        world.addImportantParticle(effect, x, y, z, 0.0, 0.0, 0.0);
    }

    private static double[] corner(int i, double half) {
        return switch (i % 4) {
            case 0 -> new double[]{-half, -half};
            case 1 -> new double[]{half, -half};
            case 2 -> new double[]{half, half};
            default -> new double[]{-half, half};
        };
    }

    private static LivingEntity findTarget(MinecraftClient client) {
        LivingEntity aura = KillAura.currentTarget;
        if (aura != null && aura.isAlive() && aura.squaredDistanceTo(client.player) < 24.0 * 24.0) {
            return aura;
        }
        if (client.targetedEntity instanceof LivingEntity le
                && le != client.player && le.isAlive() && !(le instanceof ArmorStandEntity)) {
            return le;
        }
        LivingEntity best = null;
        double bestDist = RANGE * RANGE;
        for (LivingEntity e : client.world.getEntitiesByClass(LivingEntity.class,
                client.player.getBoundingBox().expand(RANGE),
                x -> x != client.player && x.isAlive() && !(x instanceof ArmorStandEntity))) {
            double d = e.squaredDistanceTo(client.player);
            if (d < bestDist) {
                best = e;
                bestDist = d;
            }
        }
        return best;
    }
}
