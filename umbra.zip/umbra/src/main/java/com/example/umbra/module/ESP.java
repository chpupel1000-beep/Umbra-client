package com.example.umbra.module;

import net.minecraft.client.MinecraftClient;
import net.minecraft.entity.Entity;
import net.minecraft.entity.mob.HostileEntity;

public class ESP extends Module {
    public ESP() {
        super("ESP", "Подсвечивает мобов сквозь стены", Category.VISUALS);
    }

    @Override
    public void onTick(MinecraftClient client) {
        if (client.world == null) return;
        for (Entity e : client.world.getEntities()) {
            if (e instanceof HostileEntity) e.setGlowing(true);
        }
    }

    @Override
    public void onDisable() {
        MinecraftClient client = MinecraftClient.getInstance();
        if (client.world == null) return;
        for (Entity e : client.world.getEntities()) {
            if (e instanceof HostileEntity) e.setGlowing(false);
        }
    }
}
