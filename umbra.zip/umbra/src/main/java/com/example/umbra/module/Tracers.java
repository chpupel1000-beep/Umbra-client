package com.example.umbra.module;

import com.example.umbra.HudDraw;
import com.example.umbra.Palette;
import com.example.umbra.Theme;
import com.example.umbra.WorldDraw;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.util.math.Vec3d;

/** Линии от прицела (или низа экрана) к игрокам. Ближе = краснее, дальше = голубее. */
public class Tracers extends Module {
    private final Setting origin = addSetting("Origin", new String[]{"Bottom", "Center"}, 0);
    private final Setting thickness = addSetting("Thickness", new String[]{"1", "2"}, 0);
    private long lastTick = System.nanoTime();

    public Tracers() {
        super("Tracers", "Линии к игрокам: ближе красные, дальше голубые", Category.VISUALS);
    }

    @Override
    public void onTick(MinecraftClient client) { lastTick = System.nanoTime(); }

    @Override
    public void renderHud(DrawContext c) {
        MinecraftClient client = MinecraftClient.getInstance();
        if (client.player == null || client.world == null) return;
        WorldDraw cam = new WorldDraw(client, c);
        double t = Math.min(1.0, (System.nanoTime() - lastTick) / 50_000_000.0);
        double ox = c.getScaledWindowWidth() / 2.0;
        double oy = origin.index == 0 ? c.getScaledWindowHeight() : c.getScaledWindowHeight() / 2.0;
        double th = Integer.parseInt(thickness.value());
        for (PlayerEntity p : client.world.getPlayers()) {
            if (p == client.player || !p.isAlive()) continue;
            double dist = Math.sqrt(p.squaredDistanceTo(client.player));
            if (dist > 150) continue;
            double x = p.prevX + (p.getX() - p.prevX) * t;
            double y = p.prevY + (p.getY() - p.prevY) * t;
            double z = p.prevZ + (p.getZ() - p.prevZ) * t;
            double[] pt = cam.project(new Vec3d(x, y + p.getHeight() * 0.5, z));
            if (pt == null || Math.abs(pt[0]) > 4000 || Math.abs(pt[1]) > 4000) continue;
            int col = Palette.mix(0xFFFF4D4D, 0xFF38BDF8, (float) (dist / 60.0));
            HudDraw.line(c, ox, oy, pt[0], pt[1], th + 2.0, 0x33000000 | (col & 0xFFFFFF));
            HudDraw.line(c, ox, oy, pt[0], pt[1], th, 0xCC000000 | (col & 0xFFFFFF));
        }
    }
}
