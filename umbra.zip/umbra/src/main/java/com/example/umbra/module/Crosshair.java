package com.example.umbra.module;

import com.example.umbra.Palette;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;

/** Свой прицел вместо обычного: форма, цвет и размер. */
public class Crosshair extends Module {
    private final Setting style = addSetting("Style", new String[]{"Cross", "Plus", "Dot", "Circle"}, 0);
    private final Setting color = addSetting("Color", Palette.NAMES, 0);
    private final Setting size = addSetting("Size", new String[]{"3", "5", "8"}, 1);

    public Crosshair() {
        super("Crosshair", "Свой прицел: форма, цвет, размер", Category.VISUALS);
    }

    @Override
    public void renderHud(DrawContext c) {
        MinecraftClient client = MinecraftClient.getInstance();
        if (client.player == null || !client.options.getPerspective().isFirstPerson()) return;
        int cx = c.getScaledWindowWidth() / 2, cy = c.getScaledWindowHeight() / 2;
        int s = Integer.parseInt(size.value());
        int col = 0xFF000000 | Palette.RGB[color.index];
        int shadow = 0x99000000;
        switch (style.index) {
            case 0 -> { // крест с пропуском в центре
                int gap = 2;
                bar(c, cx - gap - s, cy, cx - gap, cy + 1, col, shadow);
                bar(c, cx + gap + 1, cy, cx + gap + 1 + s, cy + 1, col, shadow);
                bar(c, cx, cy - gap - s, cx + 1, cy - gap, col, shadow);
                bar(c, cx, cy + gap + 1, cx + 1, cy + gap + 1 + s, col, shadow);
            }
            case 1 -> { // сплошной плюс
                bar(c, cx - s, cy, cx + s + 1, cy + 1, col, shadow);
                bar(c, cx, cy - s, cx + 1, cy + s + 1, col, shadow);
            }
            case 2 -> bar(c, cx - 1, cy - 1, cx + 1, cy + 1, col, shadow);
            default -> { // кольцо
                int r = s + 2;
                for (int i = 0; i < 40; i++) {
                    double a = 2 * Math.PI * i / 40;
                    int px = cx + (int) Math.round(Math.cos(a) * r);
                    int py = cy + (int) Math.round(Math.sin(a) * r);
                    c.fill(px, py, px + 1, py + 1, col);
                }
            }
        }
    }

    private static void bar(DrawContext c, int x1, int y1, int x2, int y2, int col, int shadow) {
        c.fill(x1 - 1, y1 - 1, x2 + 1, y2 + 1, shadow);
        c.fill(x1, y1, x2, y2, col);
    }
}
