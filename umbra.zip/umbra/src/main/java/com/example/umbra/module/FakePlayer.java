package com.example.umbra.module;

import com.mojang.authlib.GameProfile;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.client.network.OtherClientPlayerEntity;
import net.minecraft.entity.Entity;
import net.minecraft.util.math.Vec3d;

import java.util.UUID;

/**
 * Манекен для тестов: фальшивый игрок, который есть только у тебя на экране.
 * На нём можно проверять KillAura, TargetHUD, TargetESP, Tracers, Nametags и DamageNumbers.
 * Ударили: у манекена убавляется HP и показывается красная вспышка; «умер»: сразу воскресает.
 * Лучше всего использовать в одиночной игре: сервер о манекене ничего не знает.
 */
public class FakePlayer extends Module {
    private final Setting moveMode = addSetting("Move", new String[]{"Stand", "Circle"}, 0);
    private final Setting damage = addSetting("Damage", new String[]{"2", "4", "6", "8"}, 1);
    private final Setting distance = addSetting("Distance", new String[]{"2", "3", "4"}, 1);

    private OtherClientPlayerEntity dummy;
    private double angle;
    private double standX, standY, standZ;
    private float prevCooldown = 1.0f;
    private int healTicks;

    public FakePlayer() {
        super("FakePlayer", "Манекен для тестов: бей его вместо мобов", Category.COMBAT);
    }

    @Override
    public void onEnable() {
        MinecraftClient c = MinecraftClient.getInstance();
        ClientPlayerEntity p = c.player;
        if (p == null || c.world == null) {
            setEnabled(false);
            return;
        }
        double d = Integer.parseInt(distance.value());
        double yaw = Math.toRadians(p.getYaw());
        standX = p.getX() - Math.sin(yaw) * d;
        standY = p.getY();
        standZ = p.getZ() + Math.cos(yaw) * d;
        angle = Math.atan2(standZ - p.getZ(), standX - p.getX());

        dummy = new OtherClientPlayerEntity(c.world, new GameProfile(UUID.nameUUIDFromBytes("umbra-dummy".getBytes()), "Dummy"));
        dummy.setId(-5151);
        dummy.setNoGravity(true);
        dummy.refreshPositionAndAngles(standX, standY, standZ, 0f, 0f);
        dummy.setHealth(dummy.getMaxHealth());
        c.world.addEntity(dummy);
        prevCooldown = p.getAttackCooldownProgress(0.0f);
    }

    @Override
    public void onTick(MinecraftClient c) {
        ClientPlayerEntity p = c.player;
        if (dummy == null || p == null || c.world == null || dummy.getWorld() != c.world) {
            setEnabled(false);
            return;
        }

        // Движение манекена
        double x = standX, y = standY, z = standZ;
        if (moveMode.index == 1) {
            angle += 0.06;
            double d = Integer.parseInt(distance.value());
            x = p.getX() + Math.cos(angle) * d;
            z = p.getZ() + Math.sin(angle) * d;
            y = p.getY();
        }
        // Манекен смотрит на игрока
        Vec3d to = new Vec3d(p.getX() - x, 0, p.getZ() - z);
        float yaw = (float) (Math.toDegrees(Math.atan2(to.z, to.x)) - 90.0);
        dummy.refreshPositionAndAngles(x, y, z, yaw, 0f);
        dummy.setHeadYaw(yaw);

        // Воскрешение после «смерти»
        if (healTicks > 0 && --healTicks == 0) dummy.setHealth(dummy.getMaxHealth());

        // Удар по манекену: кулдаун атаки резко падает, пока целимся в него
        float cd = p.getAttackCooldownProgress(0.0f);
        boolean aimedAtDummy = c.targetedEntity == dummy || KillAura.currentTarget == dummy;
        if (aimedAtDummy && prevCooldown > 0.5f && cd < 0.3f && healTicks == 0) {
            float hp = dummy.getHealth() - Integer.parseInt(damage.value());
            dummy.hurtTime = 10;
            dummy.maxHurtTime = 10;
            if (hp <= 0) {
                dummy.setHealth(0.5f);
                healTicks = 20; // через секунду снова полное здоровье
            } else {
                dummy.setHealth(hp);
            }
        }
        prevCooldown = cd;
    }

    @Override
    public void onDisable() {
        MinecraftClient c = MinecraftClient.getInstance();
        if (dummy != null && c.world != null) {
            c.world.removeEntity(dummy.getId(), Entity.RemovalReason.DISCARDED);
        }
        dummy = null;
        healTicks = 0;
    }
}
