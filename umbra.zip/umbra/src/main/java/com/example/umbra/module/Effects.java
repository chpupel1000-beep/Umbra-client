package com.example.umbra.module;

import com.example.umbra.HudLayout;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.entity.effect.StatusEffectInstance;

/** Список активных эффектов зелий с оставшимся временем. */
public class Effects extends Module {
    public Effects() {
        super("Effects", "Активные эффекты зелий и время", Category.VISUALS);
    }

    @Override
    public void renderHud(DrawContext c) {
        MinecraftClient client = MinecraftClient.getInstance();
        if (client.player == null) return;
        int x = HudLayout.x(HudLayout.EFFECTS, c.getScaledWindowWidth(), HudLayout.EFFECTS.w);
        int y = HudLayout.y(HudLayout.EFFECTS, c.getScaledWindowHeight(), HudLayout.EFFECTS.h);
        int row = 0;
        for (StatusEffectInstance e : client.player.getStatusEffects()) {
            if (row >= 6) break;
            String name = e.getEffectType().value().getName().getString() + " " + (e.getAmplifier() + 1);
            String time;
            if (e.isInfinite()) {
                time = "inf";
            } else {
                int s = e.getDuration() / 20;
                time = (s / 60) + ":" + String.format("%02d", s % 60);
            }
            int ry = y + row * 11;
            c.fill(x, ry, x + HudLayout.EFFECTS.w, ry + 10, 0x66101826);
            c.drawTextWithShadow(client.textRenderer, name, x + 3, ry + 1, 0xFFF1F5F9);
            c.drawTextWithShadow(client.textRenderer, time,
                    x + HudLayout.EFFECTS.w - client.textRenderer.getWidth(time) - 3, ry + 1, 0xFF7DD3FC);
            row++;
        }
    }
}
