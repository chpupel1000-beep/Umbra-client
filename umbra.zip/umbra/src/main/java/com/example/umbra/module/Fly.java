package com.example.umbra.module;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;

/** Полёт: пробел вверх, Shift вниз. Работает в одиночной игре и на своём сервере с allow-flight. */
public class Fly extends Module {
    private static final String[] NAMES = {"0.5", "1.0", "2.0", "3.0"};
    private static final double[] SPEEDS = {0.5, 1.0, 2.0, 3.0};
    private final Setting speed = addSetting("Speed", NAMES, 1);

    public Fly() {
        super("Fly", "Полёт: пробел вверх, Shift вниз", Category.MOVEMENT);
    }

    @Override
    public void onTick(MinecraftClient client) {
        ClientPlayerEntity p = client.player;
        if (p == null || p.hasVehicle() || p.getAbilities().flying) return;
        double sp = SPEEDS[speed.index];
        double fwd = p.input.movementForward, side = p.input.movementSideways;
        double len = Math.sqrt(fwd * fwd + side * side);
        if (len > 1.0) { fwd /= len; side /= len; }
        double yaw = Math.toRadians(p.getYaw());
        double vx = (side * Math.cos(yaw) - fwd * Math.sin(yaw)) * 0.35 * sp;
        double vz = (fwd * Math.cos(yaw) + side * Math.sin(yaw)) * 0.35 * sp;
        double vy = 0.0;
        if (client.options.jumpKey.isPressed()) vy += 0.3 * sp;
        if (client.options.sneakKey.isPressed()) vy -= 0.3 * sp;
        p.setVelocity(vx, vy, vz);
        p.fallDistance = 0;
    }
}
