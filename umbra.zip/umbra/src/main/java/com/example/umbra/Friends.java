package com.example.umbra;

import net.fabricmc.loader.api.FabricLoader;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.Properties;
import java.util.Set;
import java.util.TreeSet;

/** Список друзей: KillAura их не бьёт, Tracers и Nametags подсвечивают их зелёным. */
public final class Friends {
    private static final Path FILE = FabricLoader.getInstance().getConfigDir().resolve("umbra-friends.properties");
    private static final Set<String> NAMES = new TreeSet<>();

    static { load(); }

    private Friends() {}

    public static boolean is(String name) {
        return name != null && NAMES.contains(name.toLowerCase(Locale.ROOT));
    }

    public static boolean add(String name) {
        boolean added = NAMES.add(name.toLowerCase(Locale.ROOT));
        if (added) save();
        return added;
    }

    public static boolean remove(String name) {
        boolean removed = NAMES.remove(name.toLowerCase(Locale.ROOT));
        if (removed) save();
        return removed;
    }

    public static List<String> list() { return new ArrayList<>(NAMES); }

    private static void load() {
        if (!Files.exists(FILE)) return;
        Properties p = new Properties();
        try (InputStream in = Files.newInputStream(FILE)) {
            p.load(in);
        } catch (IOException e) {
            return;
        }
        String v = p.getProperty("friends", "");
        for (String n : v.split(",")) if (!n.isBlank()) NAMES.add(n.trim().toLowerCase(Locale.ROOT));
    }

    private static void save() {
        Properties p = new Properties();
        p.setProperty("friends", String.join(",", NAMES));
        try (OutputStream out = Files.newOutputStream(FILE)) {
            p.store(out, "Umbra friends");
        } catch (IOException ignored) {}
    }
}
