package com.example.umbra.gui;

import com.example.umbra.Theme;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.screen.multiplayer.MultiplayerScreen;
import net.minecraft.client.gui.screen.option.OptionsScreen;
import net.minecraft.client.gui.screen.world.SelectWorldScreen;
import net.minecraft.text.Text;

/** Своё главное меню: тёмный фон с мерцающими точками и мягким свечением, овальные кнопки. */
public class UmbraTitleScreen extends Screen {
    private static final int BTN_W = 190;
    private static final int BTN_H = 22;
    private static final int GAP = 7;

    private final String[] labels = {"Одиночная игра", "Сетевая игра", "Настройки", "Выход"};
    private int btnTop;

    public UmbraTitleScreen() {
        super(Text.literal("Umbra"));
    }

    @Override
    public boolean shouldCloseOnEsc() { return false; }

    private void layout() {
        int total = labels.length * BTN_H + (labels.length - 1) * GAP;
        btnTop = Math.max(height / 2 - 10, 100);
        if (btnTop + total > height - 24) btnTop = Math.max(70, height - 24 - total);
    }

    private int btnX() { return (width - BTN_W) / 2; }
    private int btnY(int i) { return btnTop + i * (BTN_H + GAP); }

    // ---- Рисование ----

    private static int lerpColor(int a, int b, float t) {
        t = Math.max(0f, Math.min(1f, t));
        int al = (int) (((a >>> 24) & 0xFF) + ((((b >>> 24) & 0xFF) - ((a >>> 24) & 0xFF)) * t));
        int r = (int) (((a >> 16) & 0xFF) + ((((b >> 16) & 0xFF) - ((a >> 16) & 0xFF)) * t));
        int g = (int) (((a >> 8) & 0xFF) + ((((b >> 8) & 0xFF) - ((a >> 8) & 0xFF)) * t));
        int bl = (int) ((a & 0xFF) + (((b & 0xFF) - (a & 0xFF)) * t));
        return (al << 24) | (r << 16) | (g << 8) | bl;
    }

    private static void roundRect(DrawContext c, int x, int y, int w, int h, int r, int top, int bottom) {
        r = Math.min(r, Math.min(w, h) / 2);
        for (int i = 0; i < h; i++) {
            double d = 0;
            if (i < r) d = r - (i + 0.5);
            else if (i >= h - r) d = (i + 0.5) - (h - r);
            int inset = d > 0 ? (int) Math.round(r - Math.sqrt(Math.max(0, r * r - d * d))) : 0;
            int col = top == bottom ? top : lerpColor(top, bottom, h <= 1 ? 0f : (float) i / (h - 1));
            c.fill(x + inset, y + i, x + w - inset, y + i + 1, col);
        }
    }

    @Override
    public void renderBackground(DrawContext c, int mx, int my, float delta) {
        double t = System.nanoTime() / 1.0e9;
        c.fillGradient(0, 0, width, height, 0xFF050509, 0xFF0B0B14);
        int rgb = Theme.rgb();

        // Мягкие свечения: несколько слоёв кругов с малой прозрачностью
        double[][] orbs = {{0.22, 0.30, 0.3}, {0.78, 0.65, 0.4}, {0.55, 0.15, 0.5}};
        for (int o = 0; o < orbs.length; o++) {
            int cx = (int) (width * orbs[o][0] + Math.sin(t * 0.25 + o * 2.1) * 30);
            int cy = (int) (height * orbs[o][1] + Math.cos(t * 0.2 + o) * 22);
            int radius = (int) (Math.min(width, height) * 0.28);
            for (int k = 6; k >= 1; k--) {
                int r = radius * k / 6;
                roundRect(c, cx - r, cy - r, r * 2, r * 2, r, (0x0A << 24) | rgb, (0x0A << 24) | rgb);
            }
        }

        // Мерцающие точки, медленно плывущие вверх
        for (int i = 0; i < 70; i++) {
            double fx = ((i * 7919L) % 1000) / 1000.0;
            double fy = ((i * 104729L) % 1000) / 1000.0;
            double speed = 4 + (i % 5) * 3;
            double y = ((fy * height - t * speed) % height + height) % height;
            int a = (int) (0x30 + 0x30 * Math.sin(t * 2 + i));
            int size = (i % 4 == 0) ? 2 : 1;
            int col = (a << 24) | (i % 3 == 0 ? rgb : 0xFFFFFF);
            c.fill((int) (fx * width), (int) y, (int) (fx * width) + size, (int) y + size, col);
        }
    }

    @Override
    public void render(DrawContext c, int mx, int my, float delta) {
        super.render(c, mx, my, delta);
        layout();
        int accent = Theme.accent();
        int cx = width / 2;

        // Логотип (скруглённый квадрат с буквой U)
        int sz = 46;
        int lx = cx - sz / 2;
        int ly = Math.max(10, btnTop - 108);
        roundRect(c, lx, ly, sz, sz, 12, accent, 0xFF1B1030);
        c.fill(lx + 13, ly + 11, lx + 18, ly + 34, 0xFFFFFFFF);
        c.fill(lx + 28, ly + 11, lx + 33, ly + 34, 0xFFFFFFFF);
        roundRect(c, lx + 13, ly + 29, 20, 6, 3, 0xFFFFFFFF, 0xFFFFFFFF);

        // Название крупным шрифтом
        String title = "UMBRA";
        float scale = 3.0f;
        int tw = (int) (textRenderer.getWidth(title) * scale);
        c.getMatrices().push();
        c.getMatrices().translate(cx - tw / 2.0f, ly + sz + 8, 0);
        c.getMatrices().scale(scale, scale, 1.0f);
        c.drawTextWithShadow(textRenderer, title, 0, 0, 0xFFFFFFFF);
        c.getMatrices().pop();
        String sub = "client";
        c.drawText(textRenderer, sub, cx - textRenderer.getWidth(sub) / 2, ly + sz + 8 + 28, accent, false);

        // Кнопки
        for (int i = 0; i < labels.length; i++) {
            int x = btnX(), y = btnY(i);
            boolean hov = mx >= x && mx < x + BTN_W && my >= y && my < y + BTN_H;
            boolean quit = i == labels.length - 1;
            int border = hov ? (quit ? 0xFFF87171 : accent) : 0xFF2A2A34;
            roundRect(c, x - 1, y - 1, BTN_W + 2, BTN_H + 2, 9, border, border);
            roundRect(c, x, y, BTN_W, BTN_H, 8, hov ? 0xFF16161F : 0xFF0C0C12, hov ? 0xFF1B1B26 : 0xFF101018);
            int textColor = hov ? 0xFFFFFFFF : 0xFFC7CBD4;
            c.drawText(textRenderer, labels[i], cx - textRenderer.getWidth(labels[i]) / 2, y + 7, textColor, false);
        }

        // Подвал
        String foot = "Minecraft 1.21.4  ·  Umbra client";
        c.drawText(textRenderer, foot, cx - textRenderer.getWidth(foot) / 2, height - 14, 0xFF6B7280, false);
    }

    @Override
    public boolean mouseClicked(double mx, double my, int button) {
        layout();
        if (button == 0) {
            for (int i = 0; i < labels.length; i++) {
                int x = btnX(), y = btnY(i);
                if (mx >= x && mx < x + BTN_W && my >= y && my < y + BTN_H) {
                    switch (i) {
                        case 0 -> client.setScreen(new SelectWorldScreen(this));
                        case 1 -> client.setScreen(new MultiplayerScreen(this));
                        case 2 -> client.setScreen(new OptionsScreen(this, client.options));
                        default -> client.scheduleStop();
                    }
                    return true;
                }
            }
        }
        return super.mouseClicked(mx, my, button);
    }
}
