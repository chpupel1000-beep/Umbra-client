package com.example.umbra.module;

import com.example.umbra.HudLayout;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.font.TextRenderer;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.PlayerSkinDrawer;
import net.minecraft.client.gui.screen.ingame.HandledScreen;
import net.minecraft.client.network.AbstractClientPlayerEntity;
import net.minecraft.item.ItemStack;

import java.util.Locale;

/**
 * Карточка цели: скин игрока, имя, здоровье и расстояние.
 */
public class TargetEsp extends Module {
    private static final int ACCENT = 0xFF7DD3FC;
    private static final int TEXT = 0xFFF1F5F9;
    private static final int DIM = 0xFFA9B4C6;
    private static final int BG = 0x66101826;
    private static final double TARGET_RANGE = 12.0;

    public TargetEsp() {
        super("TargetESP", "Карточка цели: скин, имя и HP игрока", Category.VISUALS);
    }

    @Override
    public void renderHud(DrawContext c) {
        MinecraftClient client = MinecraftClient.getInstance();
        if (client.player == null || client.world == null) return;
        if (client.currentScreen instanceof HandledScreen<?>) return;

        drawTarget(c, client);
    }

    /** Цель: игрок под прицелом, а если такого нет, то ближайший игрок рядом. */
    private AbstractClientPlayerEntity findTarget(MinecraftClient client) {
        if (client.targetedEntity instanceof AbstractClientPlayerEntity p
                && p != client.player && p.isAlive()) {
            return p;
        }
        AbstractClientPlayerEntity best = null;
        double bestDist = TARGET_RANGE * TARGET_RANGE;
        for (AbstractClientPlayerEntity p : client.world.getPlayers()) {
            if (p == client.player || !p.isAlive()) continue;
            double d = p.squaredDistanceTo(client.player);
            if (d < bestDist) {
                best = p;
                bestDist = d;
            }
        }
        return best;
    }

    private void drawTarget(DrawContext c, MinecraftClient client) {
        AbstractClientPlayerEntity target = findTarget(client);
        if (target == null) return;
        TextRenderer tr = client.textRenderer;

        int pw = HudLayout.TARGET_W;
        int ph = HudLayout.TARGET_H;
        int px = HudLayout.x(HudLayout.TARGET, c.getScaledWindowWidth(), pw);
        int py = HudLayout.y(HudLayout.TARGET, c.getScaledWindowHeight(), ph);

        // Стеклянная карточка
        c.fill(px, py, px + pw, py + ph, BG);
        c.fillGradient(px, py + 1, px + pw, py + ph / 2, 0x22FFFFFF, 0x00FFFFFF);
        c.fill(px, py, px + pw, py + 1, ACCENT);

        // Скин (лицо) игрока
        PlayerSkinDrawer.draw(c, target.getSkinTextures(), px + 4, py + 4, 28);

        // Имя
        String name = tr.trimToWidth(target.getName().getString(), pw - 40);
        c.drawTextWithShadow(tr, name, px + 36, py + 5, TEXT);

        // Полоска здоровья
        float hp = target.getHealth();
        float max = Math.max(1.0f, target.getMaxHealth());
        float frac = Math.max(0.0f, Math.min(1.0f, hp / max));
        int bx = px + 36;
        int by = py + 17;
        int bw = pw - 42;
        c.fill(bx, by, bx + bw, by + 6, 0x44FFFFFF);
        c.fill(bx, by, bx + Math.round(bw * frac), by + 6, mix(0xFFFF4D4D, 0xFF4ADE80, frac));

        // Числа: здоровье и расстояние
        double dist = Math.sqrt(target.squaredDistanceTo(client.player));
        String info = fmt(hp) + " / " + fmt(max) + " HP   " + (int) dist + "m";
        c.drawTextWithShadow(tr, info, px + 36, py + 26, DIM);
    }

    private static String fmt(float v) {
        return String.format(Locale.ROOT, "%.1f", v);
    }

    private static int mix(int a, int b, float t) {
        int r = (int) (((a >> 16) & 0xFF) * (1 - t) + ((b >> 16) & 0xFF) * t);
        int g = (int) (((a >> 8) & 0xFF) * (1 - t) + ((b >> 8) & 0xFF) * t);
        int bl = (int) ((a & 0xFF) * (1 - t) + (b & 0xFF) * t);
        return 0xFF000000 | (r << 16) | (g << 8) | bl;
    }
}
