package com.example.umbra.module;

import com.mojang.authlib.GameProfile;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.client.network.OtherClientPlayerEntity;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.client.util.InputUtil;
import net.minecraft.entity.Entity;
import org.lwjgl.glfw.GLFW;

/**
 * Свободная камера: ты остаёшься на месте, а камера летает отдельно.
 * Управление: W A S D, пробел вверх, Left Shift вниз, мышь поворачивает камеру.
 * Выключил: камера возвращается, взгляд как был.
 */
public class Freecam extends Module {
    private final Setting speed = addSetting("Speed", new String[]{"0.5", "1", "2", "4"}, 1);
    private static final double[] SPEEDS = {0.5, 1.0, 2.0, 4.0};

    private OtherClientPlayerEntity cam;
    private float savedYaw, savedPitch;

    public Freecam() {
        super("Freecam", "Свободная камера: WASD, пробел, Shift", Category.VISUALS);
    }

    @Override
    public void onEnable() {
        MinecraftClient c = MinecraftClient.getInstance();
        ClientPlayerEntity p = c.player;
        if (p == null || c.world == null) {
            setEnabled(false);
            return;
        }
        GameProfile profile = p.getGameProfile();
        cam = new OtherClientPlayerEntity(c.world, profile);
        cam.setId(-4242);
        cam.refreshPositionAndAngles(p.getX(), p.getY(), p.getZ(), p.getYaw(), p.getPitch());
        savedYaw = p.getYaw();
        savedPitch = p.getPitch();
        c.world.addEntity(cam);
        c.setCameraEntity(cam);
    }

    @Override
    public void onTick(MinecraftClient c) {
        ClientPlayerEntity p = c.player;
        if (cam == null || p == null || c.world == null || cam.getWorld() != c.world) {
            setEnabled(false);
            return;
        }
        // Настоящий игрок стоит на месте: сбрасываем нажатия игровых клавиш
        KeyBinding.unpressAll();

        double fwd = 0, side = 0, up = 0;
        if (c.currentScreen == null) {
            long w = c.getWindow().getHandle();
            if (InputUtil.isKeyPressed(w, GLFW.GLFW_KEY_W)) fwd += 1;
            if (InputUtil.isKeyPressed(w, GLFW.GLFW_KEY_S)) fwd -= 1;
            if (InputUtil.isKeyPressed(w, GLFW.GLFW_KEY_A)) side += 1;
            if (InputUtil.isKeyPressed(w, GLFW.GLFW_KEY_D)) side -= 1;
            if (InputUtil.isKeyPressed(w, GLFW.GLFW_KEY_SPACE)) up += 1;
            if (InputUtil.isKeyPressed(w, GLFW.GLFW_KEY_LEFT_SHIFT)) up -= 1;
        }
        double len = Math.sqrt(fwd * fwd + side * side);
        if (len > 1.0) { fwd /= len; side /= len; }
        double yaw = Math.toRadians(p.getYaw());
        double sp = 0.5 * SPEEDS[speed.index];
        double nx = cam.getX() + (side * Math.cos(yaw) - fwd * Math.sin(yaw)) * sp;
        double nz = cam.getZ() + (fwd * Math.cos(yaw) + side * Math.sin(yaw)) * sp;
        double ny = cam.getY() + up * sp;
        cam.refreshPositionAndAngles(nx, ny, nz, p.getYaw(), p.getPitch());
        cam.setHeadYaw(p.getYaw());
    }

    @Override
    public void onDisable() {
        MinecraftClient c = MinecraftClient.getInstance();
        if (c.player != null) {
            c.setCameraEntity(c.player);
            c.player.setYaw(savedYaw);
            c.player.setPitch(savedPitch);
        }
        if (cam != null && c.world != null) {
            c.world.removeEntity(cam.getId(), Entity.RemovalReason.DISCARDED);
        }
        cam = null;
    }
}
