package com.example.umbra.module;

import com.example.umbra.WorldDraw;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.entity.LivingEntity;
import net.minecraft.util.math.Vec3d;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/** Всплывающие цифры урона над существом, когда оно теряет здоровье. */
public class DamageNumbers extends Module {
    private static final long LIFE_MS = 1000;

    private static final class Pop {
        final double x, y, z;
        final String text;
        final long born = System.currentTimeMillis();

        Pop(double x, double y, double z, String text) {
            this.x = x;
            this.y = y;
            this.z = z;
            this.text = text;
        }
    }

    private final Map<Integer, Float> lastHealth = new HashMap<>();
    private final List<Pop> pops = new ArrayList<>();

    public DamageNumbers() {
        super("DamageNumbers", "Цифры урона над существами", Category.VISUALS);
    }

    @Override
    public void onDisable() {
        lastHealth.clear();
        pops.clear();
    }

    @Override
    public void onTick(MinecraftClient client) {
        if (client.player == null || client.world == null) return;
        if (lastHealth.size() > 400) lastHealth.clear();
        for (LivingEntity e : client.world.getEntitiesByClass(LivingEntity.class,
                client.player.getBoundingBox().expand(32.0), x -> x.isAlive())) {
            float hp = e.getHealth();
            Float prev = lastHealth.put(e.getId(), hp);
            if (prev != null && hp < prev - 0.05f && e != client.player) {
                pops.add(new Pop(e.getX() + (Math.random() - 0.5) * 0.4, e.getY() + e.getHeight() + 0.2,
                        e.getZ() + (Math.random() - 0.5) * 0.4, String.format("-%.1f", prev - hp)));
            }
        }
        long now = System.currentTimeMillis();
        pops.removeIf(p -> now - p.born > LIFE_MS);
    }

    @Override
    public void renderHud(DrawContext c) {
        MinecraftClient client = MinecraftClient.getInstance();
        if (client.player == null || pops.isEmpty()) return;
        WorldDraw cam = new WorldDraw(client, c);
        long now = System.currentTimeMillis();
        for (Pop p : new ArrayList<>(pops)) {
            double f = (now - p.born) / (double) LIFE_MS;
            double[] pt = cam.project(new Vec3d(p.x, p.y + f * 0.9, p.z));
            if (pt == null) continue;
            int alpha = (int) (255 * (1.0 - f * f));
            int w = client.textRenderer.getWidth(p.text);
            c.drawTextWithShadow(client.textRenderer, p.text, (int) pt[0] - w / 2, (int) pt[1],
                    (Math.max(16, alpha) << 24) | 0xFF5555);
        }
    }
}
