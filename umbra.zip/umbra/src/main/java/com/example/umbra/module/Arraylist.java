package com.example.umbra.module;

import com.example.umbra.UmbraMod;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;

/** Список включённых модулей в правом верхнем углу. */
public class Arraylist extends Module {
    public Arraylist() {
        super("Arraylist", "Список включённых модулей справа сверху", Category.VISUALS);
    }

    @Override
    public void renderHud(DrawContext c) {
        MinecraftClient client = MinecraftClient.getInstance();
        if (client.player == null) return;
        List<Module> on = new ArrayList<>();
        for (Module m : UmbraMod.MODULES.getModules()) {
            if (m.isEnabled() && m != this) on.add(m);
        }
        on.sort(Comparator.comparingInt((Module m) -> -client.textRenderer.getWidth(label(m))));
        int right = c.getScaledWindowWidth() - 3;
        int y = 3;
        for (Module m : on) {
            String text = label(m);
            int w = client.textRenderer.getWidth(text);
            c.fill(right - w - 6, y, right, y + 11, 0x99000000);
            c.fill(right - 2, y, right, y + 11, com.example.umbra.Theme.accent());
            c.drawTextWithShadow(client.textRenderer, text, right - w - 4, y + 2, 0xFFE5E7EB);
            y += 11;
        }
    }

    private static String label(Module m) {
        String mode = m.getSettings().isEmpty() ? m.getModeName() : m.getSettings().get(0).value();
        return mode.isEmpty() ? m.getName() : m.getName() + " " + mode;
    }
}
