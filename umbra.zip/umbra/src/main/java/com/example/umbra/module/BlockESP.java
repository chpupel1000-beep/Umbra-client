package com.example.umbra.module;

import com.example.umbra.WorldDraw;
import net.minecraft.block.Block;
import net.minecraft.block.BlockState;
import net.minecraft.block.Blocks;
import net.minecraft.block.ShulkerBoxBlock;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.registry.tag.BlockTags;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Vec3d;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;

/** Подсветка руды и сундуков сквозь стены: метки поверх экрана. Для сингла и своего сервера. */
public class BlockESP extends Module {
    private static final class Found {
        final BlockPos pos;
        final int rgb;

        Found(BlockPos pos, int rgb) {
            this.pos = pos;
            this.rgb = rgb;
        }
    }

    private final Setting type = addSetting("Type", new String[]{"Ores", "Chests", "Both"}, 2);
    private final Setting range = addSetting("Range", new String[]{"12", "16", "20", "24"}, 2);
    private final List<Found> found = new ArrayList<>();
    private int ticks;

    public BlockESP() {
        super("BlockESP", "Руда и сундуки сквозь стены (метки)", Category.VISUALS);
    }

    @Override
    public void onDisable() { found.clear(); }

    private int classify(BlockState s) {
        boolean ores = type.index != 1, chests = type.index != 0;
        if (ores) {
            if (s.isIn(BlockTags.DIAMOND_ORES)) return 0x38BDF8;
            if (s.isIn(BlockTags.EMERALD_ORES)) return 0x22C55E;
            if (s.isIn(BlockTags.GOLD_ORES)) return 0xFACC15;
            if (s.isIn(BlockTags.REDSTONE_ORES)) return 0xEF4444;
            if (s.isIn(BlockTags.LAPIS_ORES)) return 0x3B82F6;
            if (s.isIn(BlockTags.IRON_ORES)) return 0xD6B8A0;
            if (s.isOf(Blocks.ANCIENT_DEBRIS)) return 0xA16207;
        }
        if (chests) {
            Block b = s.getBlock();
            if (s.isOf(Blocks.CHEST) || s.isOf(Blocks.TRAPPED_CHEST)) return 0xF97316;
            if (s.isOf(Blocks.ENDER_CHEST)) return 0xA855F7;
            if (b instanceof ShulkerBoxBlock) return 0xEC4899;
        }
        return -1;
    }

    @Override
    public void onTick(MinecraftClient client) {
        if (client.player == null || client.world == null) return;
        if (ticks++ % 20 != 0) return; // сканируем раз в секунду
        int r = Integer.parseInt(range.value());
        BlockPos origin = client.player.getBlockPos();
        List<Found> out = new ArrayList<>();
        BlockPos.Mutable m = new BlockPos.Mutable();
        for (int dx = -r; dx <= r; dx++) {
            for (int dy = -r; dy <= r; dy++) {
                for (int dz = -r; dz <= r; dz++) {
                    m.set(origin.getX() + dx, origin.getY() + dy, origin.getZ() + dz);
                    BlockState s = client.world.getBlockState(m);
                    if (s.isAir()) continue;
                    int rgb = classify(s);
                    if (rgb >= 0) out.add(new Found(m.toImmutable(), rgb));
                }
            }
        }
        out.sort(Comparator.comparingDouble(f -> f.pos.getSquaredDistance(origin)));
        found.clear();
        for (int i = 0; i < Math.min(out.size(), 250); i++) found.add(out.get(i));
    }

    @Override
    public void renderHud(DrawContext c) {
        MinecraftClient client = MinecraftClient.getInstance();
        if (client.player == null || found.isEmpty()) return;
        WorldDraw cam = new WorldDraw(client, c);
        for (Found f : new ArrayList<>(found)) {
            Vec3d center = Vec3d.ofCenter(f.pos);
            double[] pt = cam.project(center);
            if (pt == null) continue;
            double dist = Math.sqrt(client.player.squaredDistanceTo(center));
            int half = (int) Math.max(3, Math.min(10, 120.0 / Math.max(dist, 1.0)));
            int x = (int) pt[0], y = (int) pt[1];
            int col = 0xFF000000 | f.rgb;
            c.fill(x - half - 1, y - half - 1, x + half + 1, y + half + 1, 0x88000000);
            c.fill(x - half, y - half, x + half, y - half + 1, col);
            c.fill(x - half, y + half - 1, x + half, y + half, col);
            c.fill(x - half, y - half, x - half + 1, y + half, col);
            c.fill(x + half - 1, y - half, x + half, y + half, col);
            if (dist < 16) {
                String t = (int) dist + "m";
                c.drawTextWithShadow(client.textRenderer, t, x - client.textRenderer.getWidth(t) / 2, y + half + 3, col);
            }
        }
    }
}
