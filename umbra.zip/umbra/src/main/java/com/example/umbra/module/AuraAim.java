package com.example.umbra.module;

/** Включает самонаведение KillAura: игрок сам поворачивается лицом к цели. */
public class AuraAim extends Module {
    public AuraAim() {
        super("AuraAim", "KillAura сама наводится на цель", Category.COMBAT);
    }

    @Override
    public void onEnable() { KillAura.aim = true; }

    @Override
    public void onDisable() { KillAura.aim = false; }
}
