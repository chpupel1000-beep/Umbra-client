package com.example.umbra;

import java.util.ArrayList;
import java.util.List;

/** Очередь всплывающих плашек «Модуль: ON/OFF». Рисует модуль Notifications. */
public final class Notifications {
    public static final class Toast {
        public final String text;
        public final boolean on;
        public final long born = System.currentTimeMillis();

        Toast(String text, boolean on) {
            this.text = text;
            this.on = on;
        }
    }

    public static final long LIFE_MS = 2200;
    public static final List<Toast> TOASTS = new ArrayList<>();

    private Notifications() {}

    public static synchronized void push(String name, boolean on) {
        prune();
        TOASTS.add(new Toast(name, on));
        while (TOASTS.size() > 6) TOASTS.remove(0);
    }

    public static synchronized void prune() {
        long now = System.currentTimeMillis();
        TOASTS.removeIf(t -> now - t.born > LIFE_MS);
    }
}
