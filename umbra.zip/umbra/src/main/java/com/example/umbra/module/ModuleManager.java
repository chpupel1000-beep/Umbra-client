package com.example.umbra.module;

import net.fabricmc.loader.api.FabricLoader;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.util.InputUtil;
import net.minecraft.text.Text;
import org.lwjgl.glfw.GLFW;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.List;
import java.util.Properties;

public class ModuleManager {
    private final List<Module> modules = new ArrayList<>();
    private final Path bindFile = FabricLoader.getInstance().getConfigDir().resolve("umbra-binds.properties");

    public void init() {
        // Добавить новый модуль = одна строка здесь
        register(new KillAura(), GLFW.GLFW_KEY_R);
        register(new Sprint(), GLFW.GLFW_KEY_UNKNOWN);
        register(new Fullbright(), GLFW.GLFW_KEY_UNKNOWN);
        register(new NoRender(), GLFW.GLFW_KEY_UNKNOWN);
        register(new ESP(), GLFW.GLFW_KEY_UNKNOWN);
        register(new Arrows(), GLFW.GLFW_KEY_UNKNOWN);
        register(new Arraylist(), GLFW.GLFW_KEY_UNKNOWN);
        register(new ThemeSettings(), GLFW.GLFW_KEY_UNKNOWN);
        register(new Toasts(), GLFW.GLFW_KEY_UNKNOWN);
        register(new Watermark(), GLFW.GLFW_KEY_UNKNOWN);
        register(new Tracers(), GLFW.GLFW_KEY_UNKNOWN);
        register(new Nametags(), GLFW.GLFW_KEY_UNKNOWN);
        register(new HitMarker(), GLFW.GLFW_KEY_UNKNOWN);
        register(new Cape(), GLFW.GLFW_KEY_UNKNOWN);
        register(new Wings(), GLFW.GLFW_KEY_UNKNOWN);
        register(new Trails(), GLFW.GLFW_KEY_UNKNOWN);
        register(new Zoom(), GLFW.GLFW_KEY_UNKNOWN);
        register(new Crosshair(), GLFW.GLFW_KEY_UNKNOWN);
        register(new TimeChanger(), GLFW.GLFW_KEY_UNKNOWN);
        register(new Keystrokes(), GLFW.GLFW_KEY_UNKNOWN);
        register(new Cps(), GLFW.GLFW_KEY_UNKNOWN);
        register(new Info(), GLFW.GLFW_KEY_UNKNOWN);
        register(new ArmorHud(), GLFW.GLFW_KEY_UNKNOWN);
        register(new Effects(), GLFW.GLFW_KEY_UNKNOWN);
        register(new Speed(), GLFW.GLFW_KEY_UNKNOWN);
        register(new Fly(), GLFW.GLFW_KEY_UNKNOWN);
        register(new AutoTool(), GLFW.GLFW_KEY_UNKNOWN);
        register(new Nuker(), GLFW.GLFW_KEY_UNKNOWN);
        register(new TargetHud(), GLFW.GLFW_KEY_UNKNOWN);
        register(new AuraPlayers(), GLFW.GLFW_KEY_UNKNOWN);
        register(new AuraAim(), GLFW.GLFW_KEY_UNKNOWN);
        register(new Hitbox(), GLFW.GLFW_KEY_UNKNOWN);
        register(new SwingAnimation(), GLFW.GLFW_KEY_UNKNOWN);
        register(new InventoryHud(), GLFW.GLFW_KEY_UNKNOWN);
        register(new TargetEsp(), GLFW.GLFW_KEY_UNKNOWN);
        load();
    }

    private void register(Module m, int defaultKey) {
        m.key = defaultKey;
        modules.add(m);
    }

    public List<Module> getModules() { return modules; }

    @SuppressWarnings("unchecked")
    public <T extends Module> T get(Class<T> type) {
        for (Module m : modules) if (type.isInstance(m)) return (T) m;
        return null;
    }

    /** Включённая анимация удара или null. */
    public SwingAnimation getActiveSwing() {
        SwingAnimation s = get(SwingAnimation.class);
        return (s != null && s.isEnabled()) ? s : null;
    }

    /** Поиск модуля по имени без учёта регистра. */
    public Module find(String name) {
        for (Module m : modules) if (m.getName().equalsIgnoreCase(name)) return m;
        return null;
    }

    public void setKey(Module m, int key) {
        m.key = key;
        save();
    }

    public void tick(MinecraftClient client) {
        long window = client.getWindow().getHandle();
        for (Module m : modules) {
            if (m.key != GLFW.GLFW_KEY_UNKNOWN) {
                boolean down = InputUtil.isKeyPressed(window, m.key);
                // Срабатывает только вне меню и чата, один раз на нажатие
                if (down && !m.keyDown && client.currentScreen == null) {
                    m.toggle();
                    if (client.player != null) {
                        client.player.sendMessage(Text.literal(
                                m.getName() + ": " + (m.isEnabled() ? "ON" : "OFF")), true);
                    }
                }
                m.keyDown = down;
            }
            if (m.isEnabled()) m.onTick(client);
        }
    }

    private void load() { readFrom(bindFile, false); }

    private void readFrom(Path file, boolean withEnabled) {
        if (!Files.exists(file)) return;
        Properties p = new Properties();
        try (InputStream in = Files.newInputStream(file)) {
            p.load(in);
        } catch (IOException e) {
            return;
        }
        for (Module m : modules) {
            String v = p.getProperty(m.getName());
            if (v != null) {
                try { m.key = Integer.parseInt(v.trim()); } catch (NumberFormatException ignored) {}
            }
            for (Module.Setting s : m.getSettings()) {
                String sv = p.getProperty(m.getName() + "." + s.name);
                if (sv == null) continue;
                try {
                    int idx = Integer.parseInt(sv.trim());
                    if (idx >= 0 && idx < s.options.length) s.index = idx;
                } catch (NumberFormatException ignored) {}
            }
            if (withEnabled) {
                String ev = p.getProperty(m.getName() + ".enabled");
                if (ev != null) m.setEnabled(Boolean.parseBoolean(ev.trim()));
            }
            String mv = p.getProperty(m.getName() + ".mode");
            if (mv != null) {
                try {
                    int idx = Integer.parseInt(mv.trim());
                    if (idx >= 0 && idx < m.getModes().size()) m.mode = idx;
                } catch (NumberFormatException ignored) {}
            }
        }
    }

    /** Сохраняет привязки клавиш и выбранные режимы. */
    public void save() { writeTo(bindFile, false); }

    private void writeTo(Path file, boolean withEnabled) {
        Properties p = new Properties();
        for (Module m : modules) {
            p.setProperty(m.getName(), String.valueOf(m.key));
            for (Module.Setting s : m.getSettings()) {
                p.setProperty(m.getName() + "." + s.name, String.valueOf(s.index));
            }
            if (!m.getModes().isEmpty()) p.setProperty(m.getName() + ".mode", String.valueOf(m.mode));
            if (withEnabled) p.setProperty(m.getName() + ".enabled", String.valueOf(m.isEnabled()));
        }
        try (OutputStream out = Files.newOutputStream(file)) {
            p.store(out, "Umbra settings");
        } catch (IOException ignored) {}
    }

    // ---- Конфиги: наборы модулей и настроек ----

    private Path configDir() {
        Path dir = FabricLoader.getInstance().getConfigDir().resolve("umbra-configs");
        try { Files.createDirectories(dir); } catch (IOException ignored) {}
        return dir;
    }

    public static boolean validConfigName(String name) {
        return name != null && name.matches("[A-Za-z0-9_-]{1,32}");
    }

    public void saveConfig(String name) { writeTo(configDir().resolve(name + ".properties"), true); }

    public boolean loadConfig(String name) {
        Path f = configDir().resolve(name + ".properties");
        if (!Files.exists(f)) return false;
        readFrom(f, true);
        save();
        return true;
    }

    public List<String> listConfigs() {
        List<String> out = new ArrayList<>();
        try (var stream = Files.list(configDir())) {
            stream.forEach(f -> {
                String n = f.getFileName().toString();
                if (n.endsWith(".properties")) out.add(n.substring(0, n.length() - ".properties".length()));
            });
        } catch (IOException ignored) {}
        return out;
    }
}
