package com.example.umbra.module;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.util.InputUtil;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.mob.HostileEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.util.Hand;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Vec3d;

import org.lwjgl.glfw.GLFW;

import java.util.List;

public class KillAura extends Module {
    /** Бить ли игроков (включается модулем AuraPlayers). */
    public static boolean attackPlayers = false;
    /** Поворачиваться к цели (включается модулем AuraAim). */
    public static boolean aim = false;
    /** Цель, которую KillAura выбрала на этом тике (для TargetHUD). */
    public static LivingEntity currentTarget;

    // Дальность удара: считается от глаз до ближайшей точки хитбокса цели,
    // так же, как проверяет сервер. Больше 4.0 сервер всё равно не примет.
    private static final String[] NAMES = {"Reach 3.0", "Reach 3.5", "Reach 4.0"};
    private static final double[] REACH = {3.0, 3.5, 4.0};

    /** Мы уже навелись на цель на предыдущем тике. */
    private boolean aimed;

    public KillAura() {
        super("KillAura", "Бьёт мобов, а игроков пока держишь End", Category.COMBAT);
    }

    @Override
    public List<String> getModes() { return List.of(NAMES); }

    private double reach() {
        return REACH[Math.max(0, Math.min(mode, REACH.length - 1))];
    }

    @Override
    public void onDisable() {
        aimed = false;
        currentTarget = null;
    }

    @Override
    public void onTick(MinecraftClient client) {
        PlayerEntity player = client.player;
        if (player == null || client.world == null || client.interactionManager == null) return;
        if (client.currentScreen != null) { aimed = false; return; }

        // Небольшой запас: сервер сравнивает дальность строго «меньше»
        double reach = reach() - 0.05;
        Vec3d eye = player.getEyePos();

        // Пока зажат End, KillAura бьёт ещё и игроков и выбирает их в первую очередь
        boolean holdPlayers = InputUtil.isKeyPressed(client.getWindow().getHandle(), GLFW.GLFW_KEY_END);

        LivingEntity target = null;
        double best = Double.MAX_VALUE;
        for (LivingEntity e : client.world.getEntitiesByClass(
                LivingEntity.class, player.getBoundingBox().expand(reach + 1.0), x -> true)) {
            if (e == player || !e.isAlive() || !isValid(e, holdPlayers)) continue;
            double d = distanceToBox(eye, e.getBoundingBox());
            if (d > reach) continue;
            if (!player.canSee(e)) continue; // не бить сквозь стены
            double score = (holdPlayers && e instanceof PlayerEntity) ? d - 1000.0 : d;
            if (score >= best) continue;
            target = e;
            best = score;
        }
        currentTarget = target;
        if (target == null) { aimed = false; return; }

        if (aim) {
            faceTarget(player, eye, target);
            // Сервер узнаёт о повороте с пакетом движения следующего тика,
            // поэтому первый удар после наведения делаем на тик позже.
            if (!aimed) { aimed = true; return; }
        }

        if (player.getAttackCooldownProgress(0.5f) < 1.0f) return;

        client.interactionManager.attackEntity(player, target);
        player.swingHand(Hand.MAIN_HAND);
    }

    /** Поворачивает игрока лицом к центру цели. */
    private static void faceTarget(PlayerEntity player, Vec3d eye, LivingEntity target) {
        Box b = target.getBoundingBox();
        double dx = (b.minX + b.maxX) / 2.0 - eye.x;
        double dy = (b.minY + b.maxY) / 2.0 - eye.y;
        double dz = (b.minZ + b.maxZ) / 2.0 - eye.z;
        double horizontal = Math.sqrt(dx * dx + dz * dz);
        float yaw = (float) (Math.toDegrees(Math.atan2(dz, dx)) - 90.0);
        float pitch = (float) -Math.toDegrees(Math.atan2(dy, horizontal));
        player.setYaw(yaw);
        player.setPitch(MathHelper.clamp(pitch, -90.0f, 90.0f));
    }

    private static boolean isValid(LivingEntity e, boolean holdPlayers) {
        return e instanceof HostileEntity
                || (e instanceof PlayerEntity && (attackPlayers || holdPlayers));
    }

    /** Расстояние от точки до ближайшей точки коробки. */
    private static double distanceToBox(Vec3d p, Box b) {
        double x = MathHelper.clamp(p.x, b.minX, b.maxX);
        double y = MathHelper.clamp(p.y, b.minY, b.maxY);
        double z = MathHelper.clamp(p.z, b.minZ, b.maxZ);
        return p.distanceTo(new Vec3d(x, y, z));
    }
}
