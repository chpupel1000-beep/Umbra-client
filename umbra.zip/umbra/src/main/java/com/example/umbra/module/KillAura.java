package com.example.umbra.module;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.util.InputUtil;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.mob.HostileEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.util.Hand;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Vec3d;

import org.lwjgl.glfw.GLFW;

import java.util.List;

public class KillAura extends Module {
    /** Цель, которую KillAura выбрала на этом тике (для TargetHUD). */
    public static LivingEntity currentTarget;

    // Дальность удара: считается от глаз до ближайшей точки хитбокса цели,
    // так же, как проверяет сервер. Больше 4.0 сервер всё равно не примет.
    private static final double[] REACH = {3.0, 3.5, 4.0, 5.0, 6.0};
    private static final int[] FOVS = {360, 180, 120, 90};

    private final Setting range = addSetting("Range", new String[]{"3.0", "3.5", "4.0", "5.0", "6.0"}, 2);
    private final Setting targets = addSetting("Target", new String[]{"Mobs", "Mobs + Players", "Players", "All"}, 1);
    private final Setting aim = addSetting("Aim", new String[]{"Off", "Silent", "Visible"}, 1);
    private final Setting priority = addSetting("Priority", new String[]{"Distance", "Health", "Crosshair"}, 0);
    private final Setting fov = addSetting("FOV", new String[]{"360", "180", "120", "90"}, 0);
    // Cooldown: с какого заряда атаки бить. Full = максимальный урон, но реже; Spam = очень часто, но слабые удары
    // Jump: Crits — бьёт в прыжке (с середины и при падении); End — только в самом конце прыжка, перед приземлением.
    // Стоя на земле и при подъёме вверх KillAura ничего не делает.
    private final Setting jump = addSetting("Jump", new String[]{"Off", "Crits", "End"}, 2);
    private final Setting cooldown = addSetting("Cooldown", new String[]{"Full", "80%", "50%", "Spam"}, 1);
    private static final float[] COOLDOWNS = {1.0f, 0.8f, 0.5f, 0.0f};
    private int sinceAttack = 100;

    /** Мы уже навелись на цель на предыдущем тике. */
    private boolean aimed;
    // Look: Crosshair — цель берётся, только когда ты навёл на неё прицел (угол до цели до ~20°)
    private final Setting look = addSetting("Cursor", new String[]{"Off", "Crosshair"}, 0);
    // AutoJump: сам прыгает, когда рядом есть цель, и бьёт в конце прыжка
    private final Setting autoJump = addSetting("AutoJump", new String[]{"Off", "On"}, 1);
    private boolean jumpHeld;
    // Mode: Single — одна цель; Multi — каждый удар сразу по всем целям в радиусе (до 6)
    private final Setting mode2 = addSetting("Hits", new String[]{"Single", "Multi"}, 1);
    // Weapon: перед ударом берёт в руку лучший меч/топор из хотбара
    private final Setting weapon = addSetting("Weapon", new String[]{"Off", "Best"}, 1);

    public KillAura() {
        super("KillAura", "Бьёт цели рядом: Range, Targets (мобы и игроки), Aim, Priority, FOV", Category.COMBAT);
    }

    private double reach() {
        return REACH[Math.max(0, Math.min(range.index, REACH.length - 1))];
    }

    @Override
    public void onDisable() {
        aimed = false;
        currentTarget = null;
        headInit = false;
        releaseJump();
    }

    private void releaseJump() {
        if (!jumpHeld) return;
        jumpHeld = false;
        MinecraftClient c = MinecraftClient.getInstance();
        if (c != null && c.options != null) c.options.jumpKey.setPressed(false);
    }

    @Override
    public void onTick(MinecraftClient client) {
        PlayerEntity player = client.player;
        if (player == null || client.world == null || client.interactionManager == null) return;
        if (client.currentScreen != null) { aimed = false; return; }

        // Небольшой запас: сервер сравнивает дальность строго «меньше»
        double reach = reach() - 0.05;
        Vec3d eye = player.getEyePos();

        // Пока зажат End, KillAura бьёт ещё и игроков и выбирает их в первую очередь
        boolean holdPlayers = InputUtil.isKeyPressed(client.getWindow().getHandle(), GLFW.GLFW_KEY_END);

        LivingEntity target = null;
        double best = Double.MAX_VALUE;
        String why = "рядом никого нет";
        java.util.ArrayList<LivingEntity> valid = new java.util.ArrayList<>();
        for (LivingEntity e : client.world.getEntitiesByClass(
                LivingEntity.class, player.getBoundingBox().expand(reach + 1.0), x -> true)) {
            if (e == player || !e.isAlive()) continue;
            if (!isValid(e, holdPlayers)) { why = e.getName().getString() + ": не подходит под Target"; continue; }
            if (e instanceof PlayerEntity pe && com.example.umbra.Friends.is(pe.getName().getString())) { why = e.getName().getString() + ": друг"; continue; } // друзей не бьём
            double d = distanceToBox(eye, e.getBoundingBox());
            if (d > reach) { why = e.getName().getString() + ": далеко " + String.format("%.1f", d); continue; }
            if (!player.canSee(e)) { why = e.getName().getString() + ": за стеной"; continue; } // не бить сквозь стены
            double angle = angleTo(player, eye, e);
            if (fov.index > 0 && angle > FOVS[fov.index] / 2.0) { why = e.getName().getString() + ": вне FOV"; continue; }
            if (look.index == 1 && angle > 20.0) { why = e.getName().getString() + ": не в прицеле (" + (int) angle + "°)"; continue; }
            valid.add(e);
            double base = switch (priority.index) {
                case 1 -> e.getHealth();
                case 2 -> angle;
                default -> d;
            };
            double score = (holdPlayers && e instanceof PlayerEntity) ? base - 1000.0 : base;
            if (score >= best) continue;
            target = e;
            best = score;
        }
        currentTarget = target;
        if (target == null) { aimed = false; headInit = false; releaseJump(); status(player, why); return; }

        // Silent: голова всё время смотрит на цель (камера не двигается, видно в F5)
        if (aim.index == 1) lookHead(player, eye, target);

        // Jump = Crits: на земле и при подъёме вверх не бьём и не наводимся, как статуя
        if (jump.index >= 1 && (player.isOnGround() || player.getVelocity().y > 0.1)) {
            aimed = false;
            if (!player.isOnGround()) releaseJump();
            if (autoJump.index == 1 && player.isOnGround()) {
                client.options.jumpKey.setPressed(true);
                jumpHeld = true;
            }
            status(player, target.getName().getString() + ": жду прыжок");
            return;
        }
        releaseJump();
        // End: ждём конец прыжка: падаем и земля уже близко (меньше блока под ногами)
        if (jump.index == 2) {
            boolean falling = player.getVelocity().y < 0.0;
            boolean groundNear = !client.world.isSpaceEmpty(player, player.getBoundingBox().offset(0.0, -1.5, 0.0));
            if (!(falling && groundNear)) {
                aimed = false;
                status(player, target.getName().getString() + ": жду конец прыжка");
                return;
            }
        }

        // Aim: Off — не наводится; Silent — камера не двигается; Visible — камера поворачивается к цели
        if (aim.index == 2) {
            faceTarget(player, eye, target);
            // Сервер узнаёт о повороте с пакетом движения следующего тика,
            // поэтому первый удар после наведения делаем на тик позже.
            if (!aimed) { aimed = true; return; }
        }

        if (weapon.index == 1) equipBest(player); // до проверки заряда: смена слота сбрасывает заряд
        sinceAttack++;
        // Spam бьёт не чаще раза в 2 тика, у остальных ограничивает заряд атаки
        if (player.getAttackCooldownProgress(0.5f) < COOLDOWNS[cooldown.index]) { status(player, "заряд удара"); return; }
        if (cooldown.index == 3 && sinceAttack < 2) return;
        sinceAttack = 0;
        status(player, "бью " + target.getName().getString());

        // Multi: бьём всех подходящих целей разом (самые близкие первыми, до 6), Single: только выбранную
        java.util.List<LivingEntity> victims = new java.util.ArrayList<>();
        victims.add(target);
        if (mode2.index == 1) {
            valid.sort(java.util.Comparator.comparingDouble(x -> distanceToBox(eye, x.getBoundingBox())));
            for (LivingEntity v : valid) {
                if (victims.size() >= 6) break;
                if (v != target) victims.add(v);
            }
        }
        float oldYaw = player.getYaw(), oldPitch = player.getPitch();
        for (LivingEntity v : victims) {
            if (aim.index == 1) faceTarget(player, eye, v); // Silent: наводимся только на момент удара
            client.interactionManager.attackEntity(player, v);
        }
        player.swingHand(Hand.MAIN_HAND);
        if (aim.index == 1) {
            player.setYaw(oldYaw);
            player.setPitch(oldPitch);
            lookHead(player, eye, target);
        }
    }

    /** Берёт в руку лучший меч или топор из хотбара. */
    private static void equipBest(PlayerEntity player) {
        int bestSlot = -1, bestScore = -1;
        for (int i = 0; i < 9; i++) {
            net.minecraft.item.ItemStack st = player.getInventory().getStack(i);
            if (st.isEmpty()) continue;
            String id = net.minecraft.registry.Registries.ITEM.getId(st.getItem()).getPath();
            boolean sword = id.endsWith("_sword");
            boolean axe = id.endsWith("_axe");
            if (!sword && !axe) continue;
            int tier = id.startsWith("netherite") ? 5 : id.startsWith("diamond") ? 4 : id.startsWith("iron") ? 3
                    : id.startsWith("stone") ? 2 : id.startsWith("golden") ? 1 : 0;
            int score = tier * 2 + (sword ? 1 : 0);
            if (score > bestScore) { bestScore = score; bestSlot = i; }
        }
        if (bestSlot >= 0 && player.getInventory().selectedSlot != bestSlot) {
            player.getInventory().selectedSlot = bestSlot;
        }
    }

    /** Поворачивает только голову модели к цели, камера и тело остаются на месте. */
    private static void lookHead(PlayerEntity player, Vec3d eye, LivingEntity target) {
        Box b = target.getBoundingBox();
        double dx = (b.minX + b.maxX) / 2.0 - eye.x;
        double dz = (b.minZ + b.maxZ) / 2.0 - eye.z;
        float yaw = (float) (Math.toDegrees(Math.atan2(dz, dx)) - 90.0);
        // Тело доворачивается к цели, только если голове не хватает угла (макс. 70° от тела)
        float rel = MathHelper.wrapDegrees(yaw - player.bodyYaw);
        if (Math.abs(rel) > 70.0f) {
            player.bodyYaw += rel - Math.signum(rel) * 70.0f;
        }
        float want = player.bodyYaw + MathHelper.wrapDegrees(yaw - player.bodyYaw);
        // Свой угол головы храним отдельно, иначе между кадрами она двоится (ванильный prev)
        if (!headInit) { headCur = want; headInit = true; }
        headPrev = headCur;
        headCur = want;
        player.prevHeadYaw = headPrev;
        player.headYaw = headCur;
    }

    /** Диагностика: в строке над хотбаром видно, почему KillAura сейчас не бьёт. */
    private static void status(PlayerEntity player, String text) {
        player.sendMessage(net.minecraft.text.Text.literal("KillAura: " + text), true);
    }

    private static float headCur, headPrev;
    private static boolean headInit;

    /** Поворачивает игрока лицом к центру цели. */
    private static void faceTarget(PlayerEntity player, Vec3d eye, LivingEntity target) {
        Box b = target.getBoundingBox();
        double dx = (b.minX + b.maxX) / 2.0 - eye.x;
        double dy = (b.minY + b.maxY) / 2.0 - eye.y;
        double dz = (b.minZ + b.maxZ) / 2.0 - eye.z;
        double horizontal = Math.sqrt(dx * dx + dz * dz);
        float yaw = (float) (Math.toDegrees(Math.atan2(dz, dx)) - 90.0);
        float pitch = (float) -Math.toDegrees(Math.atan2(dy, horizontal));
        player.setYaw(yaw);
        player.setPitch(MathHelper.clamp(pitch, -90.0f, 90.0f));
    }

    private boolean isValid(LivingEntity e, boolean holdPlayers) {
        if (e instanceof net.minecraft.entity.decoration.ArmorStandEntity) return false;
        return switch (targets.index) {
            case 1 -> e instanceof HostileEntity || e instanceof PlayerEntity;
            case 2 -> e instanceof PlayerEntity;
            case 3 -> true;
            default -> e instanceof HostileEntity || (e instanceof PlayerEntity && holdPlayers);
        };
    }

    /** Угол в градусах между взглядом и направлением на центр цели. */
    private static double angleTo(PlayerEntity player, Vec3d eye, LivingEntity e) {
        Box b = e.getBoundingBox();
        Vec3d center = new Vec3d((b.minX + b.maxX) / 2.0, (b.minY + b.maxY) / 2.0, (b.minZ + b.maxZ) / 2.0);
        Vec3d dir = center.subtract(eye);
        if (dir.lengthSquared() < 1.0e-6) return 0.0;
        double dot = MathHelper.clamp(player.getRotationVec(1.0f).dotProduct(dir.normalize()), -1.0, 1.0);
        return Math.toDegrees(Math.acos(dot));
    }

    /** Расстояние от точки до ближайшей точки коробки. */
    private static double distanceToBox(Vec3d p, Box b) {
        double x = MathHelper.clamp(p.x, b.minX, b.maxX);
        double y = MathHelper.clamp(p.y, b.minY, b.maxY);
        double z = MathHelper.clamp(p.z, b.minZ, b.maxZ);
        return p.distanceTo(new Vec3d(x, y, z));
    }
}
