package com.example.umbra.module;

import net.minecraft.client.MinecraftClient;

/** Приближение камеры: включил — приблизило, выключил — вернулось как было. */
public class Zoom extends Module {
    private static final String[] LEVELS = {"2x", "3x", "4x", "6x"};
    private static final int[] FOVS = {40, 30, 20, 12};
    private int savedFov = -1;

    private final Setting level = addSetting("Level", LEVELS, 1);

    public Zoom() {
        super("Zoom", "Приближение камеры (как в OptiFine)", Category.VISUALS);
    }

    @Override
    public void onEnable() {
        MinecraftClient c = MinecraftClient.getInstance();
        if (c.options == null) return;
        savedFov = c.options.getFov().getValue();
    }

    @Override
    public void onTick(MinecraftClient client) {
        if (savedFov < 0) savedFov = client.options.getFov().getValue();
        int target = FOVS[level.index];
        if (client.options.getFov().getValue() != target) client.options.getFov().setValue(target);
    }

    @Override
    public void onDisable() {
        MinecraftClient c = MinecraftClient.getInstance();
        if (c.options != null && savedFov > 0) c.options.getFov().setValue(savedFov);
        savedFov = -1;
    }
}
