package com.example.umbra.module;

import com.example.umbra.HudLayout;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.entity.player.PlayerInventory;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;

/** Сколько у тебя тотемов, стрел, жемчуга эндера и золотых яблок. */
public class ItemCounter extends Module {
    private static final Item[] ITEMS = {Items.TOTEM_OF_UNDYING, Items.ARROW, Items.ENDER_PEARL,
            Items.GOLDEN_APPLE, Items.EXPERIENCE_BOTTLE};

    public ItemCounter() {
        super("ItemCounter", "Тотемы, стрелы, жемчуг, яблоки: сколько осталось", Category.VISUALS);
    }

    private static int count(PlayerInventory inv, Item item) {
        int total = 0;
        for (int i = 0; i < inv.size(); i++) {
            ItemStack s = inv.getStack(i);
            if (s.isOf(item)) total += s.getCount();
        }
        return total;
    }

    @Override
    public void renderHud(DrawContext c) {
        MinecraftClient client = MinecraftClient.getInstance();
        if (client.player == null) return;
        int x = HudLayout.x(HudLayout.COUNTER, c.getScaledWindowWidth(), HudLayout.COUNTER.w);
        int y = HudLayout.y(HudLayout.COUNTER, c.getScaledWindowHeight(), HudLayout.COUNTER.h);
        c.fill(x, y, x + HudLayout.COUNTER.w, y + HudLayout.COUNTER.h, 0x66101826);
        int cx = x + 3;
        for (Item item : ITEMS) {
            int n = count(client.player.getInventory(), item);
            c.drawItem(new ItemStack(item), cx, y + 2);
            c.drawTextWithShadow(client.textRenderer, String.valueOf(n), cx + 17, y + 6,
                    n == 0 ? 0xFF6B7280 : 0xFFF1F5F9);
            cx += 20 + client.textRenderer.getWidth(String.valueOf(n));
        }
    }
}
