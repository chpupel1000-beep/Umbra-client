package com.example.umbra.module;

import com.example.umbra.HudLayout;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.ingame.HandledScreen;
import net.minecraft.item.ItemStack;

/**
 * Рисует на экране содержимое рюкзака (3 ряда по 9 ячеек).
 */
public class InventoryHud extends Module {
    private static final int ACCENT = 0xFF7DD3FC;
    private static final int BG = 0x66101826;

    public InventoryHud() {
        super("Inventory", "Инвентарь (3 ряда рюкзака) на экране", Category.MISC);
    }

    @Override
    public void renderHud(DrawContext c) {
        MinecraftClient client = MinecraftClient.getInstance();
        if (client.player == null || client.world == null) return;
        if (client.currentScreen instanceof HandledScreen<?>) return;

        drawInventory(c, client);
    }

    private void drawInventory(DrawContext c, MinecraftClient client) {
        int pw = HudLayout.INV_W;
        int ph = HudLayout.INV_H;
        int x = HudLayout.x(HudLayout.INVENTORY, c.getScaledWindowWidth(), pw);
        int y = HudLayout.y(HudLayout.INVENTORY, c.getScaledWindowHeight(), ph);

        c.fill(x, y, x + pw, y + ph, BG);
        c.fill(x, y, x + pw, y + 1, ACCENT);

        for (int i = 0; i < 27; i++) {
            int sx = x + 4 + (i % 9) * 18 + 1;
            int sy = y + 4 + (i / 9) * 18 + 1;
            c.fill(sx, sy, sx + 16, sy + 16, 0x22FFFFFF);
            ItemStack stack = client.player.getInventory().getStack(9 + i);
            if (!stack.isEmpty()) {
                c.drawItem(stack, sx, sy);
                c.drawStackOverlay(client.textRenderer, stack, sx, sy);
            }
        }
    }

}
