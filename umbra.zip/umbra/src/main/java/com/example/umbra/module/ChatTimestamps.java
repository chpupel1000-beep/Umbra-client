package com.example.umbra.module;

/** Добавляет время [HH:mm] перед каждым сообщением в чате. Сам текст добавляет ChatHudMixin. */
public class ChatTimestamps extends Module {
    public ChatTimestamps() {
        super("ChatTimestamps", "Время [HH:mm] перед сообщениями в чате", Category.MISC);
    }
}
