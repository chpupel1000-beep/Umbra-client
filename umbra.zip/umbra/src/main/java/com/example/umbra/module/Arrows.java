package com.example.umbra.module;

import com.example.umbra.HudLayout;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.util.math.Vec3d;

import java.util.List;

/** Треугольники вокруг прицела, указывающие направление на других игроков. */
public class Arrows extends Module {
    private static final double MAX_DIST = 100.0;

    private static final String[] NAMES = {"Tiny", "Small", "Medium", "Large"};
    private static final float[] SIZES = {2.5f, 3.5f, 5.0f, 7.0f};

    public Arrows() {
        super("Arrows", "Треугольники указывают направление на игроков", Category.VISUALS);
        mode = 1; // Small по умолчанию
    }

    @Override
    public List<String> getModes() { return List.of(NAMES); }

    private float size() {
        return SIZES[Math.max(0, Math.min(mode, SIZES.length - 1))];
    }

    @Override
    public void renderHud(DrawContext c) {
        MinecraftClient client = MinecraftClient.getInstance();
        if (client.player == null || client.world == null) return;

        int w = c.getScaledWindowWidth();
        int h = c.getScaledWindowHeight();
        float cx = HudLayout.ARROWS.fx * w;
        float cy = HudLayout.ARROWS.fy * h;
        float radius = Math.min(w, h) / 3.5f;
        float size = size();
        double viewYaw = Math.toRadians(client.gameRenderer.getCamera().getYaw());
        Vec3d me = client.player.getPos();

        for (PlayerEntity p : client.world.getPlayers()) {
            if (p == client.player || !p.isAlive()) continue;
            Vec3d d = p.getPos().subtract(me);
            double dist = d.length();
            if (dist > MAX_DIST) continue;

            // Угол на цель относительно взгляда: 0 = прямо, плюс = вправо
            double rel = Math.atan2(-d.x, d.z) - viewYaw;
            while (rel > Math.PI) rel -= 2 * Math.PI;
            while (rel < -Math.PI) rel += 2 * Math.PI;

            float dx = (float) Math.sin(rel);
            float dy = (float) -Math.cos(rel);
            float px = -dy;
            float py = dx;
            float bx = cx + dx * radius;
            float by = cy + dy * radius;
            bx = Math.max(12.0f, Math.min(w - 12.0f, bx));
            by = Math.max(12.0f, Math.min(h - 12.0f, by));

            // Ближе = краснее, дальше = голубее
            float t = (float) Math.min(1.0, dist / 60.0);
            int color = mix(0xFFFF4D4D, 0xFF7DD3FC, t);

            triangle(c, bx, by, dx, dy, px, py, size + 1.3f, 0xAA000000); // тёмный контур
            triangle(c, bx, by, dx, dy, px, py, size, color);
            float labelOffset = size * 2.0f + 6.0f;

            String label = (int) dist + "m";
            int lw = client.textRenderer.getWidth(label);
            c.drawTextWithShadow(client.textRenderer, label,
                    Math.round(bx - dx * labelOffset - lw / 2.0f), Math.round(by - dy * labelOffset - 4), 0xFFF1F5F9);
        }
    }

    private static void triangle(DrawContext c, float bx, float by, float dx, float dy,
                                 float px, float py, float size, int color) {
        float tipX = bx + dx * size * 1.4f, tipY = by + dy * size * 1.4f;
        float lX = bx - dx * size * 0.4f + px * size * 0.8f, lY = by - dy * size * 0.4f + py * size * 0.8f;
        float rX = bx - dx * size * 0.4f - px * size * 0.8f, rY = by - dy * size * 0.4f - py * size * 0.8f;
        fillTriangle(c, tipX, tipY, lX, lY, rX, rY, color);
    }

    // Заливка треугольника горизонтальными полосами
    private static void fillTriangle(DrawContext c, float x1, float y1, float x2, float y2,
                                     float x3, float y3, int color) {
        int minY = (int) Math.floor(Math.min(y1, Math.min(y2, y3)));
        int maxY = (int) Math.ceil(Math.max(y1, Math.max(y2, y3)));
        float[][] edges = {{x1, y1, x2, y2}, {x2, y2, x3, y3}, {x3, y3, x1, y1}};
        for (int y = minY; y <= maxY; y++) {
            float sy = y + 0.5f;
            float left = Float.MAX_VALUE, right = -Float.MAX_VALUE;
            for (float[] e : edges) {
                float ya = e[1], yb = e[3];
                if (ya == yb || sy < Math.min(ya, yb) || sy > Math.max(ya, yb)) continue;
                float x = e[0] + (sy - ya) / (yb - ya) * (e[2] - e[0]);
                left = Math.min(left, x);
                right = Math.max(right, x);
            }
            if (left <= right) {
                int xl = (int) Math.floor(left);
                int xr = Math.max(xl + 1, (int) Math.ceil(right));
                c.fill(xl, y, xr, y + 1, color);
            }
        }
    }

    private static int mix(int a, int b, float t) {
        int r = (int) (((a >> 16) & 0xFF) * (1 - t) + ((b >> 16) & 0xFF) * t);
        int g = (int) (((a >> 8) & 0xFF) * (1 - t) + ((b >> 8) & 0xFF) * t);
        int bl = (int) ((a & 0xFF) * (1 - t) + (b & 0xFF) * t);
        return 0xFF000000 | (r << 16) | (g << 8) | bl;
    }
}
