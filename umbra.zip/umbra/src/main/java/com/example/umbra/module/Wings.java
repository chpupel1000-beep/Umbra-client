package com.example.umbra.module;

import com.example.umbra.Palette;
import com.example.umbra.WorldDraw;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.util.math.Vec3d;

/** Крылья на спине (видны в виде от третьего лица, когда камера сзади), слегка машут. */
public class Wings extends BodyDecor {
    private static final String[] SIZES = {"Small", "Medium", "Large"};
    private static final double[] SCALES = {0.7, 1.0, 1.4};
    // Контур крыла: {в сторону, вверх, назад}
    private static final double[][] SHAPE = {
            {0.00, 0.00, 0.00}, {0.45, 0.55, 0.20}, {1.05, 0.95, 0.30}, {1.25, 0.45, 0.30},
            {1.10, -0.05, 0.28}, {0.85, -0.45, 0.25}, {0.40, -0.50, 0.15}
    };

    public Wings() {
        super("Wings", "Крылья на спине (F5)", SIZES, 1);
    }

    @Override
    protected void draw(DrawContext c, WorldDraw cam, Vec3d pos, Vec3d left, Vec3d back, int rgb) {
        double s = SCALES[size.index];
        double flap = Math.sin(System.nanoTime() / 1.0e9 * 2.5) * 0.12;
        for (int sign = -1; sign <= 1; sign += 2) {
            Vec3d[] v = new Vec3d[SHAPE.length];
            for (int i = 0; i < SHAPE.length; i++) {
                double side = SHAPE[i][0], upc = SHAPE[i][1] + side * flap, bk = SHAPE[i][2];
                v[i] = pos.add(0.0, 1.25 + upc * s, 0.0)
                        .add(back.multiply(0.14 + bk * s))
                        .add(left.multiply(sign * side * s));
            }
            for (int i = 1; i < v.length - 1; i++) {
                int col = Palette.shade(rgb, (i % 2 == 0) ? 0.78 : 1.0);
                cam.tri(c, v[0], v[i], v[i + 1], col);
            }
        }
    }
}
