package com.example.umbra;

import com.example.umbra.module.ThemeSettings;

/** Общий акцентный цвет клиента: меню, Arraylist, уведомления. Выбирается в модуле Theme или на главном экране. */
public final class Theme {
    public static final int DEFAULT = 0xA78BFA;

    private Theme() {}

    public static int rgb() {
        ThemeSettings t = UmbraMod.MODULES.get(ThemeSettings.class);
        return t != null ? t.rgb() : DEFAULT;
    }

    public static int accent() { return 0xFF000000 | rgb(); }

    /** Акцентный цвет с заданной прозрачностью (alpha 0..255). */
    public static int tint(int alpha) { return (alpha << 24) | rgb(); }
}
