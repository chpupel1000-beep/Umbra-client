package com.example.umbra.module;

public class AuraPlayers extends Module {
    public AuraPlayers() {
        super("AuraPlayers", "KillAura тоже бьёт игроков", Category.COMBAT);
    }

    @Override
    public void onEnable() { KillAura.attackPlayers = true; }

    @Override
    public void onDisable() { KillAura.attackPlayers = false; }
}
