package com.example.umbra.module;

import com.example.umbra.HudLayout;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import org.lwjgl.glfw.GLFW;

import java.util.ArrayDeque;

/** Счётчик кликов в секунду (левая | правая кнопка мыши). */
public class Cps extends Module {
    private final ArrayDeque<Long> left = new ArrayDeque<>();
    private final ArrayDeque<Long> right = new ArrayDeque<>();
    private boolean leftDown, rightDown;

    public Cps() {
        super("CPS", "Клики в секунду: левая | правая", Category.VISUALS);
    }

    @Override
    public void onTick(MinecraftClient client) {
        long now = System.currentTimeMillis();
        long window = client.getWindow().getHandle();
        boolean l = client.currentScreen == null && GLFW.glfwGetMouseButton(window, GLFW.GLFW_MOUSE_BUTTON_LEFT) == GLFW.GLFW_PRESS;
        boolean r = client.currentScreen == null && GLFW.glfwGetMouseButton(window, GLFW.GLFW_MOUSE_BUTTON_RIGHT) == GLFW.GLFW_PRESS;
        if (l && !leftDown) left.addLast(now);
        if (r && !rightDown) right.addLast(now);
        leftDown = l;
        rightDown = r;
    }

    private static int count(ArrayDeque<Long> q, long now) {
        while (!q.isEmpty() && now - q.peekFirst() > 1000) q.pollFirst();
        return q.size();
    }

    @Override
    public void renderHud(DrawContext c) {
        MinecraftClient client = MinecraftClient.getInstance();
        if (client.player == null) return;
        long now = System.currentTimeMillis();
        String text = "CPS: " + count(left, now) + " | " + count(right, now);
        int x = HudLayout.x(HudLayout.CPS, c.getScaledWindowWidth(), HudLayout.CPS.w);
        int y = HudLayout.y(HudLayout.CPS, c.getScaledWindowHeight(), HudLayout.CPS.h);
        c.fill(x, y, x + HudLayout.CPS.w, y + HudLayout.CPS.h, 0x66101826);
        c.drawTextWithShadow(client.textRenderer, text, x + 5, y + 4, 0xFFF1F5F9);
    }
}
