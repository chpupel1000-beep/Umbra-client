package com.example.umbra.module;

import com.example.umbra.HudDraw;
import com.example.umbra.Palette;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.entity.LivingEntity;
import net.minecraft.sound.SoundEvents;

/** Крестик в центре прицела, когда попал по цели (и звук на выбор). */
public class HitMarker extends Module {
    private final Setting color = addSetting("Color", Palette.NAMES, 9);
    private final Setting sound = addSetting("Sound", new String[]{"Off", "Ding", "Crit"}, 1);
    private int lastHurt;
    private int lastSwingTick = -100;
    private int tick;
    private long hitAt;

    public HitMarker() {
        super("HitMarker", "Крестик и звук при попадании по цели", Category.VISUALS);
    }

    @Override
    public void onTick(MinecraftClient client) {
        tick++;
        if (client.player == null) return;
        if (client.player.handSwinging) lastSwingTick = tick;
        int hurt = 0;
        if (client.targetedEntity instanceof LivingEntity le && le != client.player) hurt = le.hurtTime;
        // Свежий удар: hurtTime только что подскочил, и мы недавно махали рукой
        if (hurt > lastHurt && hurt >= 8 && tick - lastSwingTick <= 8) {
            hitAt = System.currentTimeMillis();
            switch (sound.index) {
                case 1 -> client.player.playSound(SoundEvents.ENTITY_EXPERIENCE_ORB_PICKUP, 0.6f, 1.6f);
                case 2 -> client.player.playSound(SoundEvents.ENTITY_PLAYER_ATTACK_CRIT, 0.6f, 1.2f);
                default -> {}
            }
        }
        lastHurt = hurt;
    }

    @Override
    public void renderHud(DrawContext c) {
        long age = System.currentTimeMillis() - hitAt;
        if (age > 350) return;
        double f = age / 350.0;
        int alpha = (int) (0xFF * (1.0 - f));
        int col = (alpha << 24) | Palette.RGB[color.index];
        double cx = c.getScaledWindowWidth() / 2.0, cy = c.getScaledWindowHeight() / 2.0;
        double g = 4 + 3 * f, len = 6;
        for (int sx = -1; sx <= 1; sx += 2) {
            for (int sy = -1; sy <= 1; sy += 2) {
                HudDraw.line(c, cx + sx * g, cy + sy * g, cx + sx * (g + len), cy + sy * (g + len), 2.0, col);
            }
        }
    }
}
