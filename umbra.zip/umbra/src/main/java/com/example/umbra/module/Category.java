package com.example.umbra.module;

public enum Category {
    COMBAT("Бой"),
    MOVEMENT("Движение"),
    VISUALS("Визуалы"),
    PLAYER("Игрок"),
    MISC("Разное");

    public final String title;

    Category(String title) { this.title = title; }
}
