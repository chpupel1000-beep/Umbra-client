package com.example.umbra.module;

import com.example.umbra.Notifications;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;

import java.util.ArrayList;
import java.util.List;

/** Плавные плашки в правом нижнем углу, когда включаешь или выключаешь модуль. */
public class Toasts extends Module {
    public Toasts() {
        super("Notifications", "Плашки при включении и выключении модулей", Category.VISUALS);
    }

    @Override
    public void renderHud(DrawContext c) {
        MinecraftClient client = MinecraftClient.getInstance();
        if (client.player == null) return;
        List<Notifications.Toast> list;
        synchronized (Notifications.class) {
            Notifications.prune();
            list = new ArrayList<>(Notifications.TOASTS);
        }
        long now = System.currentTimeMillis();
        int sw = c.getScaledWindowWidth(), sh = c.getScaledWindowHeight();
        int y = sh - 36;
        for (int i = list.size() - 1; i >= 0; i--) {
            Notifications.Toast t = list.get(i);
            long age = now - t.born;
            String text = t.text + "  " + (t.on ? "ON" : "OFF");
            int w = client.textRenderer.getWidth(text) + 16;
            double in = Math.min(1.0, age / 250.0);
            double out = Math.min(1.0, Math.max(0.0, (Notifications.LIFE_MS - age) / 300.0));
            int x = sw - 6 - (int) Math.round(w * (1.0 - in * in));
            int alpha = (int) (0xDD * out);
            int bar = t.on ? 0xFF4ADE80 : 0xFFF87171;
            c.fill(x, y, x + w, y + 16, (alpha << 24) | 0x101014);
            c.fill(x, y, x + 2, y + 16, bar);
            c.drawTextWithShadow(client.textRenderer, text, x + 8, y + 4, ((int) (0xFF * out) << 24) | 0xF1F5F9);
            y -= 19;
        }
    }
}
