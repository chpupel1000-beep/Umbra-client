package com.example.umbra.mixin;

import com.example.umbra.UmbraMod;
import com.example.umbra.module.Hitbox;
import com.example.umbra.module.NoRender;
import net.minecraft.client.MinecraftClient;
import net.minecraft.entity.Entity;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(Entity.class)
public abstract class EntityMixin {
    // Hitbox: расширяет или сужает зону, по которой прицел определяет попадание
    @Inject(method = "getTargetingMargin", at = @At("RETURN"), cancellable = true, require = 0)
    private void umbra$targetingMargin(CallbackInfoReturnable<Float> cir) {
        Hitbox hitbox = UmbraMod.MODULES.get(Hitbox.class);
        if (hitbox == null || !hitbox.isEnabled()) return;

        MinecraftClient client = MinecraftClient.getInstance();
        Entity self = (Entity) (Object) this;
        // Только клиентский мир и только чужие существа
        if (client.world == null || self.getWorld() != client.world || self == client.player) return;

        cir.setReturnValue(cir.getReturnValue() + hitbox.margin());
    }

    // NoRender (Fire): наш игрок «не горит» для отрисовки, поэтому огонь перед глазами не рисуется
    @Inject(method = "isOnFire", at = @At("RETURN"), cancellable = true, require = 0)
    private void umbra$noFireOverlay(CallbackInfoReturnable<Boolean> cir) {
        if (!cir.getReturnValue()) return;
        NoRender noRender = UmbraMod.MODULES.get(NoRender.class);
        if (noRender == null || !noRender.isEnabled() || !noRender.noFire()) return;
        if ((Object) this == MinecraftClient.getInstance().player) cir.setReturnValue(false);
    }

    // NoRender (Fire): не рисовать языки пламени на существах
    @Inject(method = "doesRenderOnFire", at = @At("RETURN"), cancellable = true, require = 0)
    private void umbra$noFireModel(CallbackInfoReturnable<Boolean> cir) {
        if (!cir.getReturnValue()) return;
        NoRender noRender = UmbraMod.MODULES.get(NoRender.class);
        if (noRender == null || !noRender.isEnabled() || !noRender.noFire()) return;
        MinecraftClient client = MinecraftClient.getInstance();
        Entity self = (Entity) (Object) this;
        if (client.world != null && self.getWorld() == client.world) cir.setReturnValue(false);
    }
}
