package com.example.umbra;

import net.fabricmc.loader.api.FabricLoader;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.Properties;

/**
 * Позиции элементов HUD. Хранятся как доли экрана (0..1), поэтому одинаково
 * работают на любом разрешении и масштабе интерфейса. Сохраняются в config.
 */
public final class HudLayout {
    public static final int INV_W = 9 * 18 + 8;
    public static final int INV_H = 3 * 18 + 8;
    public static final int TARGET_W = 124;
    public static final int TARGET_H = 36;

    public static final class Pos {
        public final String id;
        private final float defX, defY;
        public float fx, fy;
        /** Размер и подпись для простых HUD-блоков (0 = особый элемент). */
        public final int w, h;
        public final String label;

        Pos(String id, float defX, float defY) { this(id, defX, defY, 0, 0, ""); }

        Pos(String id, float defX, float defY, int w, int h, String label) {
            this.id = id;
            this.defX = defX;
            this.defY = defY;
            this.w = w;
            this.h = h;
            this.label = label;
            reset();
        }

        public void reset() { fx = defX; fy = defY; }
    }

    // Для Inventory и TargetESP (fx, fy) = положение левого верхнего угла,
    // для Arrows = положение центра круга.
    public static final Pos INVENTORY = new Pos("inventory", 0.0f, 0.5f);
    public static final Pos TARGET = new Pos("target", 0.62f, 0.58f);
    public static final Pos ARROWS = new Pos("arrows", 0.5f, 0.5f);
    public static final Pos KEYS = new Pos("keys", 0.02f, 0.62f, 64, 72, "Keystrokes");
    public static final Pos CPS = new Pos("cps", 0.02f, 0.50f, 70, 16, "CPS");
    public static final Pos INFO = new Pos("info", 0.01f, 0.07f, 112, 37, "Info");
    public static final Pos ARMOR = new Pos("armor", 0.40f, 0.86f, 112, 22, "ArmorHud");
    public static final Pos EFFECTS = new Pos("effects", 0.86f, 0.40f, 120, 66, "Effects");
    public static final Pos WATERMARK = new Pos("watermark", 0.005f, 0.005f, 178, 16, "Watermark");
    public static final Pos COUNTER = new Pos("counter", 0.30f, 0.93f, 150, 20, "ItemCounter");
    public static final Pos[] SIMPLE = {KEYS, CPS, INFO, ARMOR, EFFECTS, WATERMARK, COUNTER};
    private static final Pos[] ALL = {INVENTORY, TARGET, ARROWS, KEYS, CPS, INFO, ARMOR, EFFECTS, WATERMARK, COUNTER};

    private static final Path FILE = FabricLoader.getInstance().getConfigDir().resolve("umbra-hud.properties");

    private HudLayout() {}

    public static int x(Pos p, int screenW, int elemW) {
        return Math.round(p.fx * Math.max(0, screenW - elemW));
    }

    public static int y(Pos p, int screenH, int elemH) {
        return Math.round(p.fy * Math.max(0, screenH - elemH));
    }

    /** Ставит элемент так, чтобы его левый верхний угол оказался в (x, y). */
    public static void setFromTopLeft(Pos p, int x, int y, int screenW, int screenH, int elemW, int elemH) {
        p.fx = clamp(x / (float) Math.max(1, screenW - elemW));
        p.fy = clamp(y / (float) Math.max(1, screenH - elemH));
    }

    public static float clamp(float v) { return Math.max(0.0f, Math.min(1.0f, v)); }

    public static void resetAll() {
        for (Pos p : ALL) p.reset();
        save();
    }

    public static void load() {
        if (!Files.exists(FILE)) return;
        Properties props = new Properties();
        try (InputStream in = Files.newInputStream(FILE)) {
            props.load(in);
        } catch (IOException e) {
            return;
        }
        for (Pos p : ALL) {
            try {
                String x = props.getProperty(p.id + ".x");
                String y = props.getProperty(p.id + ".y");
                if (x != null) p.fx = clamp(Float.parseFloat(x));
                if (y != null) p.fy = clamp(Float.parseFloat(y));
            } catch (NumberFormatException ignored) {}
        }
    }

    public static void save() {
        Properties props = new Properties();
        for (Pos p : ALL) {
            props.setProperty(p.id + ".x", String.valueOf(p.fx));
            props.setProperty(p.id + ".y", String.valueOf(p.fy));
        }
        try (OutputStream out = Files.newOutputStream(FILE)) {
            props.store(out, "Umbra HUD positions");
        } catch (IOException ignored) {}
    }
}
