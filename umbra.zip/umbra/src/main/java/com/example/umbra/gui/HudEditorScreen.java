package com.example.umbra.gui;

import com.example.umbra.HudLayout;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.text.Text;

/** Редактор позиций HUD: элементы перетаскиваются мышью. */
public class HudEditorScreen extends Screen {
    private static final int ACCENT = 0xFF7DD3FC;
    private static final int TEXT = 0xFFF1F5F9;
    private static final int DIM = 0xFFA9B4C6;
    private static final int BG = 0x88101826;

    private static final int ARROWS_SIZE = 40;

    private final Screen parent;
    private HudLayout.Pos dragging;
    private int offX, offY;

    public HudEditorScreen(Screen parent) {
        super(Text.literal("HUD"));
        this.parent = parent;
    }

    private HudLayout.Pos[] elements() {
        HudLayout.Pos[] simple = HudLayout.SIMPLE;
        HudLayout.Pos[] all = new HudLayout.Pos[simple.length + 3];
        all[0] = HudLayout.ARROWS;
        all[1] = HudLayout.TARGET;
        all[2] = HudLayout.INVENTORY;
        System.arraycopy(simple, 0, all, 3, simple.length);
        return all;
    }

    private int elemW(HudLayout.Pos p) {
        if (p.w > 0) return p.w;
        if (p == HudLayout.INVENTORY) return HudLayout.INV_W;
        if (p == HudLayout.TARGET) return HudLayout.TARGET_W;
        return ARROWS_SIZE;
    }

    private int elemH(HudLayout.Pos p) {
        if (p.h > 0) return p.h;
        if (p == HudLayout.INVENTORY) return HudLayout.INV_H;
        if (p == HudLayout.TARGET) return HudLayout.TARGET_H;
        return ARROWS_SIZE;
    }

    /** Левый верхний угол элемента на экране. */
    private int elemX(HudLayout.Pos p) {
        if (p == HudLayout.ARROWS) return Math.round(p.fx * width) - ARROWS_SIZE / 2;
        return HudLayout.x(p, width, elemW(p));
    }

    private int elemY(HudLayout.Pos p) {
        if (p == HudLayout.ARROWS) return Math.round(p.fy * height) - ARROWS_SIZE / 2;
        return HudLayout.y(p, height, elemH(p));
    }

    private void moveTo(HudLayout.Pos p, int x, int y) {
        if (p == HudLayout.ARROWS) {
            p.fx = HudLayout.clamp((x + ARROWS_SIZE / 2f) / width);
            p.fy = HudLayout.clamp((y + ARROWS_SIZE / 2f) / height);
        } else {
            HudLayout.setFromTopLeft(p, x, y, width, height, elemW(p), elemH(p));
        }
    }

    private static boolean inside(double mx, double my, int x, int y, int w, int h) {
        return mx >= x && mx < x + w && my >= y && my < y + h;
    }

    private static void border(DrawContext c, int x, int y, int w, int h, int color) {
        c.fill(x, y, x + w, y + 1, color);
        c.fill(x, y + h - 1, x + w, y + h, color);
        c.fill(x, y, x + 1, y + h, color);
        c.fill(x + w - 1, y, x + w, y + h, color);
    }

    @Override
    public void render(DrawContext c, int mx, int my, float delta) {
        super.render(c, mx, my, delta);

        String title = "Редактор HUD: перетаскивай элементы";
        c.drawCenteredTextWithShadow(textRenderer, title, width / 2, 8, TEXT);
        c.drawCenteredTextWithShadow(textRenderer, "Esc — готово", width / 2, 20, DIM);

        for (HudLayout.Pos p : elements()) {
            int x = elemX(p), y = elemY(p), w = elemW(p), h = elemH(p);
            boolean active = p == dragging || (dragging == null && inside(mx, my, x, y, w, h));
            c.fill(x, y, x + w, y + h, active ? 0xAA1E2A40 : BG);
            border(c, x, y, w, h, active ? ACCENT : 0x66FFFFFF);

            if (p == HudLayout.INVENTORY) {
                for (int i = 0; i < 27; i++) {
                    int sx = x + 5 + (i % 9) * 18;
                    int sy = y + 5 + (i / 9) * 18;
                    c.fill(sx, sy, sx + 16, sy + 16, 0x22FFFFFF);
                }
                c.drawCenteredTextWithShadow(textRenderer, "Inventory", x + w / 2, y + h / 2 - 4, TEXT);
            } else if (p == HudLayout.TARGET) {
                c.fill(x + 4, y + 4, x + 32, y + 32, 0x44FFFFFF);
                c.fill(x + 36, y + 17, x + w - 6, y + 23, 0x4400FF88);
                c.drawTextWithShadow(textRenderer, "TargetESP", x + 36, y + 5, TEXT);
                c.drawTextWithShadow(textRenderer, "HP", x + 36, y + 26, DIM);
            } else if (p.w > 0) {
                c.drawCenteredTextWithShadow(textRenderer, p.label, x + w / 2, y + h / 2 - 4, TEXT);
            } else {
                // Центр круга Arrows
                c.fill(x + w / 2 - 1, y + 4, x + w / 2 + 1, y + h - 4, 0x55FFFFFF);
                c.fill(x + 4, y + h / 2 - 1, x + w - 4, y + h / 2 + 1, 0x55FFFFFF);
                c.drawCenteredTextWithShadow(textRenderer, "Arrows", x + w / 2, y + h + 3, TEXT);
            }
        }

        // Кнопка сброса
        int bx = width / 2 - 45, by = height - 26;
        boolean hov = inside(mx, my, bx, by, 90, 16);
        c.fill(bx, by, bx + 90, by + 16, hov ? 0xAA1E2A40 : BG);
        border(c, bx, by, 90, 16, ACCENT);
        c.drawCenteredTextWithShadow(textRenderer, "Сбросить", width / 2, by + 4, TEXT);
    }

    @Override
    public boolean mouseClicked(double mx, double my, int button) {
        if (button == 0) {
            if (inside(mx, my, width / 2 - 45, height - 26, 90, 16)) {
                HudLayout.resetAll();
                return true;
            }
            HudLayout.Pos[] list = elements();
            for (int i = list.length - 1; i >= 0; i--) { // верхний элемент выбирается первым
                HudLayout.Pos p = list[i];
                int x = elemX(p), y = elemY(p);
                if (inside(mx, my, x, y, elemW(p), elemH(p))) {
                    dragging = p;
                    offX = (int) mx - x;
                    offY = (int) my - y;
                    return true;
                }
            }
        }
        return super.mouseClicked(mx, my, button);
    }

    @Override
    public boolean mouseDragged(double mx, double my, int button, double dx, double dy) {
        if (dragging != null) {
            moveTo(dragging, (int) mx - offX, (int) my - offY);
            return true;
        }
        return super.mouseDragged(mx, my, button, dx, dy);
    }

    @Override
    public boolean mouseReleased(double mx, double my, int button) {
        if (dragging != null) {
            dragging = null;
            HudLayout.save();
            return true;
        }
        return super.mouseReleased(mx, my, button);
    }

    @Override
    public void removed() {
        HudLayout.save();
    }

    @Override
    public void close() {
        client.setScreen(parent);
    }

    @Override
    public boolean shouldPause() { return false; }
}
