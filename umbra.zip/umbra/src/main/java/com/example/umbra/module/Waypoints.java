package com.example.umbra.module;

import com.example.umbra.WorldDraw;
import net.fabricmc.loader.api.FabricLoader;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Vec3d;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.List;
import java.util.Properties;

/** Метки на карте мира: .wp add <имя>, .wp del <имя>, .wp list. Рисует метку с расстоянием. */
public class Waypoints extends Module {
    private static final Path FILE = FabricLoader.getInstance().getConfigDir().resolve("umbra-waypoints.properties");

    private static final class Wp {
        final String name, dim;
        final int x, y, z;

        Wp(String name, String dim, int x, int y, int z) {
            this.name = name;
            this.dim = dim;
            this.x = x;
            this.y = y;
            this.z = z;
        }
    }

    private static final List<Wp> POINTS = new ArrayList<>();

    static {
        load();
    }

    public Waypoints() {
        super("Waypoints", "Метки в мире: .wp add имя", Category.VISUALS);
    }

    private static String dimension(MinecraftClient c) {
        return c.world == null ? "" : c.world.getRegistryKey().getValue().toString();
    }

    // ---- Команды ----

    public static String add(String name) {
        MinecraftClient c = MinecraftClient.getInstance();
        if (c.player == null) return "Нет игрока";
        if (!name.matches("[A-Za-z0-9_А-Яа-яЁё-]{1,24}")) return "Имя: буквы, цифры, _ и -";
        BlockPos p = c.player.getBlockPos();
        POINTS.removeIf(w -> w.name.equalsIgnoreCase(name) && w.dim.equals(dimension(c)));
        POINTS.add(new Wp(name, dimension(c), p.getX(), p.getY(), p.getZ()));
        save();
        return "Метка §a" + name + "§r: " + p.getX() + " " + p.getY() + " " + p.getZ();
    }

    public static String remove(String name) {
        MinecraftClient c = MinecraftClient.getInstance();
        boolean removed = POINTS.removeIf(w -> w.name.equalsIgnoreCase(name) && w.dim.equals(dimension(c)));
        if (removed) save();
        return removed ? "Метка §a" + name + "§r удалена" : "Такой метки нет";
    }

    public static List<String> list() {
        MinecraftClient c = MinecraftClient.getInstance();
        List<String> out = new ArrayList<>();
        for (Wp w : POINTS) {
            if (w.dim.equals(dimension(c))) out.add(w.name + " (" + w.x + " " + w.y + " " + w.z + ")");
        }
        return out;
    }

    private static void load() {
        if (!Files.exists(FILE)) return;
        Properties p = new Properties();
        try (InputStream in = Files.newInputStream(FILE)) {
            p.load(in);
        } catch (IOException e) {
            return;
        }
        for (String key : p.stringPropertyNames()) {
            // Формат: имя = dim;x;y;z
            String[] v = p.getProperty(key).split(";");
            if (v.length != 4) continue;
            try {
                POINTS.add(new Wp(key, v[0], Integer.parseInt(v[1]), Integer.parseInt(v[2]), Integer.parseInt(v[3])));
            } catch (NumberFormatException ignored) {}
        }
    }

    private static void save() {
        Properties p = new Properties();
        for (Wp w : POINTS) p.setProperty(w.name, w.dim + ";" + w.x + ";" + w.y + ";" + w.z);
        try (OutputStream out = Files.newOutputStream(FILE)) {
            p.store(out, "Umbra waypoints");
        } catch (IOException ignored) {}
    }

    // ---- Рисование ----

    @Override
    public void renderHud(DrawContext c) {
        MinecraftClient client = MinecraftClient.getInstance();
        if (client.player == null || client.world == null) return;
        String dim = dimension(client);
        WorldDraw cam = new WorldDraw(client, c);
        for (Wp w : POINTS) {
            if (!w.dim.equals(dim)) continue;
            Vec3d pos = new Vec3d(w.x + 0.5, w.y + 1.0, w.z + 0.5);
            double[] pt = cam.project(pos);
            if (pt == null) continue;
            double dist = Math.sqrt(client.player.squaredDistanceTo(pos));
            String text = w.name + "  " + (int) dist + "m";
            int tw = client.textRenderer.getWidth(text);
            int x = (int) pt[0], y = (int) pt[1];
            c.fill(x - tw / 2 - 4, y - 14, x + tw / 2 + 4, y - 2, 0xAA000000);
            c.drawTextWithShadow(client.textRenderer, text, x - tw / 2, y - 12, 0xFFFACC15);
            c.fill(x - 1, y - 2, x + 1, y + 4, 0xFFFACC15); // «ножка» метки
        }
    }
}
