package com.example.umbra.module;

import net.minecraft.client.MinecraftClient;
import net.minecraft.entity.effect.StatusEffectInstance;
import net.minecraft.entity.effect.StatusEffects;

public class Fullbright extends Module {
    public Fullbright() {
        super("Fullbright", "Ночное зрение: всё видно в темноте", Category.VISUALS);
    }

    @Override
    public void onTick(MinecraftClient client) {
        if (client.player == null) return;
        client.player.addStatusEffect(
                new StatusEffectInstance(StatusEffects.NIGHT_VISION, 1000, 0, false, false));
    }

    @Override
    public void onDisable() {
        MinecraftClient client = MinecraftClient.getInstance();
        if (client.player != null) client.player.removeStatusEffect(StatusEffects.NIGHT_VISION);
    }
}
