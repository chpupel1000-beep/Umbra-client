package com.example.umbra.mixin;

import com.example.umbra.UmbraMod;
import com.example.umbra.module.ChatTimestamps;
import net.minecraft.client.gui.hud.ChatHud;
import net.minecraft.text.Text;
import net.minecraft.util.Formatting;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.ModifyVariable;

import java.time.LocalTime;
import java.time.format.DateTimeFormatter;

@Mixin(ChatHud.class)
public abstract class ChatHudMixin {
    private static final DateTimeFormatter TIME = DateTimeFormatter.ofPattern("HH:mm");

    // ChatTimestamps: перед сообщением ставим серое время
    @ModifyVariable(method = "addMessage(Lnet/minecraft/text/Text;Lnet/minecraft/network/message/MessageSignatureData;Lnet/minecraft/client/gui/hud/MessageIndicator;)V",
            at = @At("HEAD"), argsOnly = true, require = 0)
    private Text umbra$timestamp(Text message) {
        ChatTimestamps ts = UmbraMod.MODULES.get(ChatTimestamps.class);
        if (ts == null || !ts.isEnabled()) return message;
        return Text.literal("[" + LocalTime.now().format(TIME) + "] ").formatted(Formatting.GRAY).append(message);
    }
}
