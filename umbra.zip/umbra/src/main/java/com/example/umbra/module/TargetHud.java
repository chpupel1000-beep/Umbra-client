package com.example.umbra.module;

import com.example.umbra.HudDraw;
import com.example.umbra.Palette;
import com.example.umbra.WorldDraw;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.decoration.ArmorStandEntity;
import net.minecraft.util.math.Vec3d;

/**
 * Рамка-прицел вокруг цели: четыре угловых скобки на экране.
 *  Spin: скобки вращаются вокруг цели,
 *  Still: скобки стоят ровно,
 *  Pulse: скобки пульсируют (сжимаются и расширяются).
 * Цель: та, что бьёт KillAura, иначе существо под прицелом,
 * иначе ближайшее живое существо (моб, животное или игрок) в радиусе 12 блоков.
 */
public class TargetHud extends Module {
    private static final double RANGE = 12.0;

    private final Setting style = addSetting("Style", new String[]{"Spin", "Still", "Pulse"}, 0);
    private final Setting color = addSetting("Color", Palette.NAMES, 7);
    private long lastTick = System.nanoTime();

    public TargetHud() {
        super("TargetHUD", "Вращающаяся рамка-скобки вокруг цели", Category.VISUALS);
    }

    @Override
    public void onTick(MinecraftClient client) {
        lastTick = System.nanoTime();
    }

    @Override
    public void renderHud(DrawContext c) {
        MinecraftClient client = MinecraftClient.getInstance();
        if (client.player == null || client.world == null) return;
        LivingEntity e = findTarget(client);
        if (e == null) return;

        double t = Math.min(1.0, (System.nanoTime() - lastTick) / 50_000_000.0);
        double x = e.prevX + (e.getX() - e.prevX) * t;
        double y = e.prevY + (e.getY() - e.prevY) * t;
        double z = e.prevZ + (e.getZ() - e.prevZ) * t;
        double h = e.getHeight();

        WorldDraw cam = new WorldDraw(client, c);
        double[] mid = cam.project(new Vec3d(x, y + h * 0.5, z));
        double[] bottom = cam.project(new Vec3d(x, y, z));
        double[] top = cam.project(new Vec3d(x, y + h, z));
        if (mid == null || bottom == null || top == null) return;

        double time = System.nanoTime() / 1.0e9;
        double half = Math.max(12.0, Math.min(150.0, Math.abs(bottom[1] - top[1]) * 0.55));
        double angle = 0.0;
        if (style.index == 0) angle = time * 1.8;
        if (style.index == 2) half *= 1.0 + 0.1 * Math.sin(time * 5.0);
        double len = half * 0.5;

        int rgb = Palette.RGB[color.index];
        int core = 0xFF000000 | rgb;
        int glow = 0x55000000 | rgb;
        double cos = Math.cos(angle), sin = Math.sin(angle);

        for (int sx = -1; sx <= 1; sx += 2) {
            for (int sy = -1; sy <= 1; sy += 2) {
                // Угол рамки и два луча вдоль сторон квадрата, всё повёрнуто на angle
                double[] corner = rot(sx * half, sy * half, cos, sin);
                double[] a = rot(sx * half - sx * len, sy * half, cos, sin);
                double[] b = rot(sx * half, sy * half - sy * len, cos, sin);
                HudDraw.line(c, mid[0] + corner[0], mid[1] + corner[1], mid[0] + a[0], mid[1] + a[1], 5.0, glow);
                HudDraw.line(c, mid[0] + corner[0], mid[1] + corner[1], mid[0] + b[0], mid[1] + b[1], 5.0, glow);
                HudDraw.line(c, mid[0] + corner[0], mid[1] + corner[1], mid[0] + a[0], mid[1] + a[1], 2.0, core);
                HudDraw.line(c, mid[0] + corner[0], mid[1] + corner[1], mid[0] + b[0], mid[1] + b[1], 2.0, core);
            }
        }
    }

    private static double[] rot(double x, double y, double cos, double sin) {
        return new double[]{x * cos - y * sin, x * sin + y * cos};
    }

    private static LivingEntity findTarget(MinecraftClient client) {
        LivingEntity aura = KillAura.currentTarget;
        if (aura != null && aura.isAlive() && aura.squaredDistanceTo(client.player) < 24.0 * 24.0) {
            return aura;
        }
        if (client.targetedEntity instanceof LivingEntity le
                && le != client.player && le.isAlive() && !(le instanceof ArmorStandEntity)) {
            return le;
        }
        LivingEntity best = null;
        double bestDist = RANGE * RANGE;
        for (LivingEntity e : client.world.getEntitiesByClass(LivingEntity.class,
                client.player.getBoundingBox().expand(RANGE),
                x -> x != client.player && x.isAlive() && !(x instanceof ArmorStandEntity))) {
            double d = e.squaredDistanceTo(client.player);
            if (d < bestDist) {
                best = e;
                bestDist = d;
            }
        }
        return best;
    }
}
