package com.example.umbra.module;

import com.example.umbra.HudDraw;
import com.example.umbra.Palette;
import com.example.umbra.WorldDraw;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.decoration.ArmorStandEntity;
import net.minecraft.util.math.Vec3d;

/**
 * Рамка-прицел вокруг цели: четыре угловых скобки на экране.
 *  Spin: скобки вращаются вокруг цели,
 *  Still: скобки стоят ровно,
 *  Pulse: скобки пульсируют (сжимаются и расширяются).
 * Цель: та, что бьёт KillAura, иначе существо под прицелом,
 * иначе ближайшее живое существо (моб, животное или игрок) в радиусе 12 блоков.
 */
public class TargetHud extends Module {
    private static final double RANGE = 12.0;

    private final Setting shape = addSetting("Shape", new String[]{"Brackets", "Square", "Circle", "Diamond", "Triangle", "Ticks"}, 0);
    private final Setting style = addSetting("Style", new String[]{"Spin", "Still", "Pulse"}, 0);
    private final Setting color = addSetting("Color", Palette.NAMES, 7);
    private static final String[] SCALES = {"0.5", "0.75", "1.0", "1.25", "1.5", "2.0"};
    private static final double[] SCALE_VALUES = {0.5, 0.75, 1.0, 1.25, 1.5, 2.0};
    private final Setting width = addSetting("Width", SCALES, 2);
    private final Setting height = addSetting("Height", SCALES, 2);
    private final Setting thickness = addSetting("Thickness", new String[]{"1", "2", "3", "4"}, 1);
    private long lastTick = System.nanoTime();

    public TargetHud() {
        super("TargetHUD", "Рамка вокруг цели: скобки, квадрат, круг, ромб, треугольник", Category.VISUALS);
    }

    @Override
    public void onTick(MinecraftClient client) {
        lastTick = System.nanoTime();
    }

    @Override
    public void renderHud(DrawContext c) {
        MinecraftClient client = MinecraftClient.getInstance();
        if (client.player == null || client.world == null) return;
        LivingEntity e = findTarget(client);
        if (e == null) return;

        double t = Math.min(1.0, (System.nanoTime() - lastTick) / 50_000_000.0);
        double x = e.prevX + (e.getX() - e.prevX) * t;
        double y = e.prevY + (e.getY() - e.prevY) * t;
        double z = e.prevZ + (e.getZ() - e.prevZ) * t;
        double h = e.getHeight();

        WorldDraw cam = new WorldDraw(client, c);
        double[] mid = cam.project(new Vec3d(x, y + h * 0.5, z));
        double[] bottom = cam.project(new Vec3d(x, y, z));
        double[] top = cam.project(new Vec3d(x, y + h, z));
        if (mid == null || bottom == null || top == null) return;

        double time = System.nanoTime() / 1.0e9;
        double half = Math.max(12.0, Math.min(150.0, Math.abs(bottom[1] - top[1]) * 0.55));
        double angle = 0.0;
        if (style.index == 0) angle = time * 1.8;
        if (style.index == 2) half *= 1.0 + 0.1 * Math.sin(time * 5.0);
        double halfW = half * SCALE_VALUES[width.index];
        double halfH = half * SCALE_VALUES[height.index];
        double len = Math.min(halfW, halfH) * 0.5;
        double th = Integer.parseInt(thickness.value());

        int rgb = Palette.RGB[color.index];
        int core = 0xFF000000 | rgb;
        int glow = 0x55000000 | rgb;
        double cos = Math.cos(angle), sin = Math.sin(angle);

        switch (shape.index) {
            case 0 -> { // Brackets: четыре угловые скобки
                for (int sx = -1; sx <= 1; sx += 2) {
                    for (int sy = -1; sy <= 1; sy += 2) {
                        double[][] pts = {
                                {sx * halfW - sx * len, sy * halfH},
                                {sx * halfW, sy * halfH},
                                {sx * halfW, sy * halfH - sy * len}};
                        poly(c, mid, pts, cos, sin, th, glow, core, false);
                    }
                }
            }
            case 1 -> poly(c, mid, new double[][]{{-halfW, -halfH}, {halfW, -halfH}, {halfW, halfH}, {-halfW, halfH}},
                    cos, sin, th, glow, core, true); // Square
            case 2 -> { // Circle (эллипс по Width/Height)
                int n = 36;
                double[][] pts = new double[n][];
                for (int i = 0; i < n; i++) {
                    double a2 = 2 * Math.PI * i / n;
                    pts[i] = new double[]{Math.cos(a2) * halfW, Math.sin(a2) * halfH};
                }
                poly(c, mid, pts, cos, sin, th, glow, core, true);
            }
            case 3 -> poly(c, mid, new double[][]{{0, -halfH * 1.25}, {halfW * 1.25, 0}, {0, halfH * 1.25}, {-halfW * 1.25, 0}},
                    cos, sin, th, glow, core, true); // Diamond
            case 4 -> poly(c, mid, new double[][]{{0, -halfH}, {halfW, halfH * 0.8}, {-halfW, halfH * 0.8}},
                    cos, sin, th, glow, core, true); // Triangle
            default -> { // Ticks: четыре чёрточки к центру, как прицел
                poly(c, mid, new double[][]{{-halfW, 0}, {-halfW + len, 0}}, cos, sin, th, glow, core, false);
                poly(c, mid, new double[][]{{halfW, 0}, {halfW - len, 0}}, cos, sin, th, glow, core, false);
                poly(c, mid, new double[][]{{0, -halfH}, {0, -halfH + len}}, cos, sin, th, glow, core, false);
                poly(c, mid, new double[][]{{0, halfH}, {0, halfH - len}}, cos, sin, th, glow, core, false);
            }
        }
    }

    /** Ломаная из точек (координаты относительно центра цели, с поворотом) со свечением. */
    private static void poly(DrawContext c, double[] mid, double[][] pts, double cos, double sin,
                             double th, int glow, int core, boolean closed) {
        int n = pts.length;
        int segs = closed ? n : n - 1;
        for (int pass = 0; pass < 2; pass++) {
            double w = pass == 0 ? th + 3.0 : th;
            int col = pass == 0 ? glow : core;
            for (int i = 0; i < segs; i++) {
                double[] p1 = rot(pts[i][0], pts[i][1], cos, sin);
                double[] p2 = rot(pts[(i + 1) % n][0], pts[(i + 1) % n][1], cos, sin);
                HudDraw.line(c, mid[0] + p1[0], mid[1] + p1[1], mid[0] + p2[0], mid[1] + p2[1], w, col);
            }
        }
    }

    private static double[] rot(double x, double y, double cos, double sin) {
        return new double[]{x * cos - y * sin, x * sin + y * cos};
    }

    private static LivingEntity findTarget(MinecraftClient client) {
        LivingEntity aura = KillAura.currentTarget;
        if (aura != null && aura.isAlive() && aura.squaredDistanceTo(client.player) < 24.0 * 24.0) {
            return aura;
        }
        if (client.targetedEntity instanceof LivingEntity le
                && le != client.player && le.isAlive() && !(le instanceof ArmorStandEntity)) {
            return le;
        }
        LivingEntity best = null;
        double bestDist = RANGE * RANGE;
        for (LivingEntity e : client.world.getEntitiesByClass(LivingEntity.class,
                client.player.getBoundingBox().expand(RANGE),
                x -> x != client.player && x.isAlive() && !(x instanceof ArmorStandEntity))) {
            double d = e.squaredDistanceTo(client.player);
            if (d < bestDist) {
                best = e;
                bestDist = d;
            }
        }
        return best;
    }
}
