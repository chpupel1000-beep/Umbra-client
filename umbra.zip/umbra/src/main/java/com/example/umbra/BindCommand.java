package com.example.umbra;

import com.example.umbra.module.Module;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.util.InputUtil;
import net.minecraft.text.Text;
import org.lwjgl.glfw.GLFW;

import java.lang.reflect.Field;
import java.util.stream.Collectors;

public final class BindCommand {
    private static final String PREFIX = "§d[Umbra]§r ";

    private BindCommand() {}

    /** Вызывается при отправке сообщения в чат. false = сообщение не уходит на сервер. */
    public static boolean handle(String message) {
        String text = message.trim();
        if (text.equals(".hud")) {
            UmbraMod.openHudEditor = true;
            return false;
        }
        if (!(text.equals(".bind") || text.startsWith(".bind "))) return true;

        String[] a = text.split("\\s+");
        if (a.length < 2) { usage(); return false; }

        switch (a[1].toLowerCase()) {
            case "add" -> {
                if (a.length < 4) { usage(); return false; }
                Module m = UmbraMod.MODULES.find(a[2]);
                if (m == null) { unknownModule(a[2]); return false; }
                int key = parseKey(a[3]);
                if (key == GLFW.GLFW_KEY_UNKNOWN) {
                    reply("§cНеизвестная клавиша: " + a[3] + ". Примеры: R, G, F4, RSHIFT, INSERT, KP_1");
                    return false;
                }
                UmbraMod.MODULES.setKey(m, key);
                reply("§a" + m.getName() + "§r привязан к клавише §e" + keyName(key));
            }
            case "del", "remove" -> {
                if (a.length < 3) { usage(); return false; }
                Module m = UmbraMod.MODULES.find(a[2]);
                if (m == null) { unknownModule(a[2]); return false; }
                UmbraMod.MODULES.setKey(m, GLFW.GLFW_KEY_UNKNOWN);
                reply("Привязка у §a" + m.getName() + "§r убрана");
            }
            case "list" -> {
                boolean any = false;
                for (Module m : UmbraMod.MODULES.getModules()) {
                    if (m.key != GLFW.GLFW_KEY_UNKNOWN) {
                        reply(m.getName() + " → §e" + keyName(m.key));
                        any = true;
                    }
                }
                if (!any) reply("Привязок пока нет");
            }
            default -> usage();
        }
        return false;
    }

    private static void usage() {
        reply(".bind add <модуль> <клавиша>  |  .bind del <модуль>  |  .bind list");
        reply("Пример: .bind add killaura r");
    }

    private static void unknownModule(String name) {
        String names = UmbraMod.MODULES.getModules().stream()
                .map(Module::getName).collect(Collectors.joining(", "));
        reply("§cМодуль «" + name + "» не найден. Есть: " + names);
    }

    private static void reply(String text) {
        MinecraftClient client = MinecraftClient.getInstance();
        if (client.player != null) client.player.sendMessage(Text.literal(PREFIX + text), false);
    }

    private static String keyName(int key) {
        return InputUtil.fromKeyCode(key, 0).getLocalizedText().getString();
    }

    /** Имя клавиши -> код GLFW (R, F4, RIGHT_SHIFT, KP_1 и т.д.). -1 если не найдено. */
    private static int parseKey(String name) {
        String n = name.toUpperCase().replace('-', '_');
        n = switch (n) {
            case "RSHIFT" -> "RIGHT_SHIFT";
            case "LSHIFT" -> "LEFT_SHIFT";
            case "RCTRL" -> "RIGHT_CONTROL";
            case "LCTRL" -> "LEFT_CONTROL";
            case "RALT" -> "RIGHT_ALT";
            case "LALT" -> "LEFT_ALT";
            case "DEL" -> "DELETE";
            case "CAPS" -> "CAPS_LOCK";
            case "PGUP" -> "PAGE_UP";
            case "PGDN" -> "PAGE_DOWN";
            default -> n;
        };
        if (n.equals("ESC") || n.equals("ESCAPE")) return GLFW.GLFW_KEY_UNKNOWN; // Esc занят игрой
        try {
            Field f = GLFW.class.getField("GLFW_KEY_" + n);
            return f.getInt(null);
        } catch (ReflectiveOperationException e) {
            return GLFW.GLFW_KEY_UNKNOWN;
        }
    }
}
