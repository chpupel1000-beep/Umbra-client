package com.example.umbra;

import com.example.umbra.module.Module;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.util.InputUtil;
import net.minecraft.text.Text;
import org.lwjgl.glfw.GLFW;

import java.lang.reflect.Field;
import java.util.stream.Collectors;

public final class BindCommand {
    private static final String PREFIX = "§d[Umbra]§r ";

    private BindCommand() {}

    /** Вызывается при отправке сообщения в чат. false = сообщение не уходит на сервер. */
    public static boolean handle(String message) {
        String text = message.trim();
        if (text.equals(".hud")) {
            UmbraMod.openHudEditor = true;
            return false;
        }
        if (text.equals(".wp") || text.startsWith(".wp ")) {
            String[] w = text.split("\\s+");
            if (w.length >= 3 && w[1].equalsIgnoreCase("add")) reply(com.example.umbra.module.Waypoints.add(w[2]));
            else if (w.length >= 3 && (w[1].equalsIgnoreCase("del") || w[1].equalsIgnoreCase("remove"))) reply(com.example.umbra.module.Waypoints.remove(w[2]));
            else if (w.length >= 2 && w[1].equalsIgnoreCase("list")) reply("Метки: " + com.example.umbra.module.Waypoints.list());
            else reply(".wp add <имя>  |  .wp del <имя>  |  .wp list  (включи модуль Waypoints, чтобы видеть метки)");
            return false;
        }
        if (text.equals(".config") || text.startsWith(".config ")) {
            config(text.split("\\s+"));
            return false;
        }
        if (!(text.equals(".bind") || text.startsWith(".bind "))) return true;

        String[] a = text.split("\\s+");
        if (a.length < 2) { usage(); return false; }

        switch (a[1].toLowerCase()) {
            case "add" -> {
                if (a.length < 4) { usage(); return false; }
                Module m = UmbraMod.MODULES.find(a[2]);
                if (m == null) { unknownModule(a[2]); return false; }
                int key = parseKey(a[3]);
                if (key == GLFW.GLFW_KEY_UNKNOWN) {
                    reply("§cНеизвестная клавиша: " + a[3] + ". Примеры: R, G, F4, RSHIFT, INSERT, KP_1");
                    return false;
                }
                UmbraMod.MODULES.setKey(m, key);
                reply("§a" + m.getName() + "§r привязан к клавише §e" + keyName(key));
            }
            case "del", "remove" -> {
                if (a.length < 3) { usage(); return false; }
                Module m = UmbraMod.MODULES.find(a[2]);
                if (m == null) { unknownModule(a[2]); return false; }
                UmbraMod.MODULES.setKey(m, GLFW.GLFW_KEY_UNKNOWN);
                reply("Привязка у §a" + m.getName() + "§r убрана");
            }
            case "list" -> {
                boolean any = false;
                for (Module m : UmbraMod.MODULES.getModules()) {
                    if (m.key != GLFW.GLFW_KEY_UNKNOWN) {
                        reply(m.getName() + " → §e" + keyName(m.key));
                        any = true;
                    }
                }
                if (!any) reply("Привязок пока нет");
            }
            default -> usage();
        }
        return false;
    }

    private static void config(String[] a) {
        if (a.length >= 3 && (a[1].equalsIgnoreCase("save") || a[1].equalsIgnoreCase("load"))) {
            String name = a[2];
            if (!com.example.umbra.module.ModuleManager.validConfigName(name)) {
                reply("§cИмя конфига: только буквы, цифры, _ и -");
                return;
            }
            if (a[1].equalsIgnoreCase("save")) {
                UmbraMod.MODULES.saveConfig(name);
                reply("Конфиг §a" + name + "§r сохранён");
            } else if (UmbraMod.MODULES.loadConfig(name)) {
                reply("Конфиг §a" + name + "§r загружен");
            } else {
                reply("§cКонфиг «" + name + "» не найден. Есть: " + UmbraMod.MODULES.listConfigs());
            }
            return;
        }
        if (a.length >= 2 && a[1].equalsIgnoreCase("list")) {
            reply("Конфиги: " + UmbraMod.MODULES.listConfigs());
            return;
        }
        reply(".config save <имя>  |  .config load <имя>  |  .config list");
    }

    private static void usage() {
        reply(".bind add <модуль> <клавиша>  |  .bind del <модуль>  |  .bind list");
        reply("Пример: .bind add killaura r");
    }

    private static void unknownModule(String name) {
        String names = UmbraMod.MODULES.getModules().stream()
                .map(Module::getName).collect(Collectors.joining(", "));
        reply("§cМодуль «" + name + "» не найден. Есть: " + names);
    }

    private static void reply(String text) {
        MinecraftClient client = MinecraftClient.getInstance();
        if (client.player != null) client.player.sendMessage(Text.literal(PREFIX + text), false);
    }

    private static String keyName(int key) {
        return InputUtil.fromKeyCode(key, 0).getLocalizedText().getString();
    }

    /** Имя клавиши -> код GLFW (R, F4, RIGHT_SHIFT, KP_1 и т.д.). -1 если не найдено. */
    private static int parseKey(String name) {
        String n = name.toUpperCase().replace('-', '_');
        n = switch (n) {
            case "RSHIFT" -> "RIGHT_SHIFT";
            case "LSHIFT" -> "LEFT_SHIFT";
            case "RCTRL" -> "RIGHT_CONTROL";
            case "LCTRL" -> "LEFT_CONTROL";
            case "RALT" -> "RIGHT_ALT";
            case "LALT" -> "LEFT_ALT";
            case "DEL" -> "DELETE";
            case "CAPS" -> "CAPS_LOCK";
            case "PGUP" -> "PAGE_UP";
            case "PGDN" -> "PAGE_DOWN";
            default -> n;
        };
        if (n.equals("ESC") || n.equals("ESCAPE")) return GLFW.GLFW_KEY_UNKNOWN; // Esc занят игрой
        try {
            Field f = GLFW.class.getField("GLFW_KEY_" + n);
            return f.getInt(null);
        } catch (ReflectiveOperationException e) {
            return GLFW.GLFW_KEY_UNKNOWN;
        }
    }
}
