package com.example.umbra.mixin;

import com.example.umbra.UmbraMod;
import com.example.umbra.module.SwingAnimation;
import net.minecraft.client.render.item.HeldItemRenderer;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.util.Arm;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(HeldItemRenderer.class)
public abstract class HeldItemRendererMixin {
    // Заменяет движение предмета при взмахе на выбранную анимацию
    @Inject(method = "applySwingOffset", at = @At("HEAD"), cancellable = true, require = 0)
    private void umbra$swingOffset(MatrixStack matrices, Arm arm, float swingProgress, CallbackInfo ci) {
        SwingAnimation swing = UmbraMod.MODULES.getActiveSwing();
        if (swing != null && swing.customTransform()) {
            swing.apply(matrices, arm, swingProgress);
            ci.cancel();
        }
    }
}
