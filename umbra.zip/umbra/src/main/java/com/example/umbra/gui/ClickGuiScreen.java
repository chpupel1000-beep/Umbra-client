package com.example.umbra.gui;

import com.example.umbra.UmbraMod;
import com.example.umbra.module.Arraylist;
import com.example.umbra.module.ArmorHud;
import com.example.umbra.module.Arrows;
import com.example.umbra.module.Category;
import com.example.umbra.module.Cps;
import com.example.umbra.module.Effects;
import com.example.umbra.module.Info;
import com.example.umbra.module.ItemCounter;
import com.example.umbra.module.InventoryHud;
import com.example.umbra.module.Keystrokes;
import com.example.umbra.module.Module;
import com.example.umbra.module.TargetEsp;
import com.example.umbra.module.TargetHud;
import com.example.umbra.module.Toasts;
import com.example.umbra.module.Watermark;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.util.InputUtil;
import net.minecraft.text.Text;
import org.lwjgl.glfw.GLFW;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

/** Тёмное минималистичное меню: вкладки сверху, модули списком. ПКМ по модулю раскрывает его настройки. */
public class ClickGuiScreen extends Screen {
    private static final int BG = 0xF0090909;
    private static final int LINE = 0xFF1F1F1F;
    private static final int ROW = 0x0DFFFFFF;
    private static final int ROW_HOVER = 0x1CFFFFFF;
    private static int accent() { return com.example.umbra.Theme.accent(); }
    private static final int TEXT = 0xFFE5E7EB;
    private static final int DIM = 0xFF6B7280;

    private static final int ROW_H = 20;
    private static final int SUB_H = 15;

    /** Элементы интерфейса: прячутся в раскрывающемся пункте «Interface» во вкладке Визуалы. */
    private static final Class<?>[] INTERFACE = {
            InventoryHud.class, TargetEsp.class, TargetHud.class, Effects.class, Keystrokes.class, Info.class,
            Cps.class, ArmorHud.class, Arraylist.class, Arrows.class, Watermark.class, Toasts.class, ItemCounter.class};
    private static boolean interfaceOpen = false;

    private static Category selected = Category.COMBAT;
    private static final Set<Module> expanded = new HashSet<>();
    private double scroll = 0;

    private int px, py, pw, ph, listX, listY, listW, listH;
    private String query = "";
    private boolean searchFocused;
    private String hoverDesc;
    private static Module bindingModule;

    public ClickGuiScreen() {
        super(Text.literal("Umbra"));
    }

    private void layout() {
        // Полноэкранное меню: чёрный фон, список модулей по центру
        // Компактное окно по центру
        pw = Math.min(width - 16, 330);
        ph = Math.min(height - 16, 230);
        px = (width - pw) / 2;
        py = (height - ph) / 2;
        searchY = py + 9;
        tabY = py + 36;
        listX = px + 12;
        listW = pw - 24;
        listY = py + 58;
        listH = Math.max(40, ph - 58 - 26);
    }

    private int tabY, searchY;
    private static final int SEARCH_H = 16;

    private int searchW() { return Math.min(170, Math.max(90, pw - 110)); }
    private int searchX() { return px + (pw - searchW()) / 2 + 12; }

    /** Овал (таблетка): строки обрезаются по скруглению. */
    private static void pill(DrawContext c, int x, int y, int w, int h, int color) {
        double r = h / 2.0;
        for (int i = 0; i < h; i++) {
            double dy = i + 0.5 - r;
            int inset = (int) Math.round(r - Math.sqrt(Math.max(0, r * r - dy * dy)));
            c.fill(x + inset, y + i, x + w - inset, y + i + 1, color);
        }
    }

    /** Свой логотип: квадрат с градиентом акцента и буквой U. */
    private void drawLogo(DrawContext c, int x, int y) {
        int s = 26;
        c.fillGradient(x, y, x + s, y + s, accent(), 0xFF1B1030);
        c.fill(x + 7, y + 6, x + 10, y + 20, 0xFFFFFFFF);
        c.fill(x + 16, y + 6, x + 19, y + 20, 0xFFFFFFFF);
        c.fill(x + 7, y + 17, x + 19, y + 20, 0xFFFFFFFF);
        c.fill(x, y, x + s, y + 1, 0x55FFFFFF);
    }

    /** Лупа из пикселей. */
    private static void drawMagnifier(DrawContext c, int x, int y, int color) {
        for (int i = 0; i < 28; i++) {
            double a = 2 * Math.PI * i / 28;
            int px = x + 5 + (int) Math.round(Math.cos(a) * 4);
            int py = y + 5 + (int) Math.round(Math.sin(a) * 4);
            c.fill(px, py, px + 1, py + 1, color);
        }
        com.example.umbra.HudDraw.line(c, x + 8.5, y + 8.5, x + 12, y + 12, 2.0, color);
    }

    /** Одна строка списка: модуль или его настройка. */
    private static final class Entry {
        Module module;
        Module.Setting setting; // null = строка модуля или строка режима
        boolean modeRow;
        boolean header;
        int indent;
        int y, h;
    }

    private static boolean isInterface(Module m) {
        for (Class<?> k : INTERFACE) if (k.isInstance(m)) return true;
        return false;
    }

    private int addModule(List<Entry> out, Module m, int indent, int y) {
        Entry e = new Entry();
        e.module = m;
        e.indent = indent;
        e.y = y;
        e.h = ROW_H;
        out.add(e);
        y += ROW_H + 2;
        if (expanded.contains(m)) {
            for (Module.Setting st : m.getSettings()) {
                Entry se = new Entry();
                se.module = m;
                se.setting = st;
                se.indent = indent;
                se.y = y;
                se.h = SUB_H;
                out.add(se);
                y += SUB_H;
            }
            if (m.getSettings().isEmpty() && !m.getModes().isEmpty()) {
                Entry me = new Entry();
                me.module = m;
                me.modeRow = true;
                me.indent = indent;
                me.y = y;
                me.h = SUB_H;
                out.add(me);
                y += SUB_H;
            }
            y += 3;
        }
        return y;
    }

    private List<Entry> entries() {
        List<Entry> out = new ArrayList<>();
        int y = 0;
        if (!query.isEmpty()) {
            String q = query.toLowerCase();
            for (Module m : UmbraMod.MODULES.getModules()) {
                if (m.getName().toLowerCase().contains(q)) y = addModule(out, m, 0, y);
            }
            return out;
        }
        if (selected == Category.VISUALS) {
            Entry head = new Entry();
            head.header = true;
            head.y = y;
            head.h = ROW_H;
            out.add(head);
            y += ROW_H + 2;
            if (interfaceOpen) {
                for (Class<?> k : INTERFACE) {
                    for (Module m : UmbraMod.MODULES.getModules()) {
                        if (k.isInstance(m)) y = addModule(out, m, 10, y);
                    }
                }
                y += 3;
            }
        }
        for (Module m : UmbraMod.MODULES.getModules()) {
            if (m.getCategory() != selected || isInterface(m)) continue;
            y = addModule(out, m, 0, y);
        }
        return out;
    }

    private static boolean expandable(Module m) {
        return !m.getSettings().isEmpty() || !m.getModes().isEmpty();
    }

    private static boolean inside(double mx, double my, int x, int y, int w, int h) {
        return mx >= x && mx < x + w && my >= y && my < y + h;
    }

    private int tabX(int index) {
        Category[] cats = Category.values();
        int total = 0;
        for (int i = 0; i < cats.length; i++) total += textRenderer.getWidth(cats[i].title) + (i > 0 ? 18 : 0);
        int x = px + (pw - total) / 2;
        for (int i = 0; i < index; i++) x += textRenderer.getWidth(cats[i].title) + 18;
        return x;
    }

    // ---- Рисование ----

    private static final int ACCENT2 = 0xFF38BDF8;
    private static final java.util.Map<Module, Float> ANIM = new java.util.HashMap<>();
    private static float interfaceAnim = 0f;

    private static int lerpColor(int a, int b, float t) {
        t = Math.max(0f, Math.min(1f, t));
        int al = (int) (((a >>> 24) & 0xFF) + ((((b >>> 24) & 0xFF) - ((a >>> 24) & 0xFF)) * t));
        int r = (int) (((a >> 16) & 0xFF) + ((((b >> 16) & 0xFF) - ((a >> 16) & 0xFF)) * t));
        int g = (int) (((a >> 8) & 0xFF) + ((((b >> 8) & 0xFF) - ((a >> 8) & 0xFF)) * t));
        int bl = (int) ((a & 0xFF) + (((b & 0xFF) - (a & 0xFF)) * t));
        return (al << 24) | (r << 16) | (g << 8) | bl;
    }

    /** Прямоугольник со срезанными углами. */
    private static void rr(DrawContext c, int x, int y, int w, int h, int color) {
        c.fill(x + 1, y, x + w - 1, y + 1, color);
        c.fill(x, y + 1, x + w, y + h - 1, color);
        c.fill(x + 1, y + h - 1, x + w - 1, y + h, color);
    }

    private static float animate(Module m, boolean on) {
        float target = on ? 1f : 0f;
        float a = ANIM.getOrDefault(m, target);
        a += (target - a) * 0.3f;
        if (Math.abs(target - a) < 0.01f) a = target;
        ANIM.put(m, a);
        return a;
    }

    private void drawSwitch(DrawContext c, int x, int y, float a) {
        rr(c, x, y, 20, 10, lerpColor(0xFF2A2A33, accent(), a));
        int kx = x + 1 + Math.round(a * 10);
        rr(c, kx, y + 1, 8, 8, lerpColor(0xFF9CA3AF, 0xFFFFFFFF, a));
    }

    @Override
    public void renderBackground(DrawContext c, int mx, int my, float delta) {
        c.fillGradient(0, 0, width, height, 0xB0000000, 0xD0000000);
    }

    @Override
    public void render(DrawContext c, int mx, int my, float delta) {
        super.render(c, mx, my, delta);
        layout();

        // Чёрное окно с тонкой рамкой и акцентной линией
        c.fill(px, py, px + pw, py + ph, 0xFF000000);
        c.fill(px, py, px + 1, py + ph, 0xFF1F1F27);
        c.fill(px + pw - 1, py, px + pw, py + ph, 0xFF1F1F27);
        c.fill(px, py + ph - 1, px + pw, py + ph, 0xFF1F1F27);
        c.fill(px, py, px + pw, py + 2, accent());

        // Логотип слева сверху
        drawLogo(c, px + 10, py + 8);

        // Поле поиска: белая таблетка с лупой по центру сверху
        int sx0 = searchX(), sw0 = searchW();
        pill(c, sx0 - 1, searchY - 1, sw0 + 2, SEARCH_H + 2, searchFocused ? accent() : 0x00000000);
        pill(c, sx0, searchY, sw0, SEARCH_H, 0xFFF5F5F7);
        drawMagnifier(c, sx0 + 8, searchY + 3, 0xFF222226);
        String shown = query.isEmpty() && !searchFocused ? "Поиск модулей" : textRenderer.trimToWidth(query, sw0 - 40);
        boolean blink = searchFocused && (System.currentTimeMillis() / 500) % 2 == 0;
        c.drawText(textRenderer, shown + (blink ? "|" : ""), sx0 + 26, searchY + 5,
                query.isEmpty() ? 0xFF8A8A93 : 0xFF111114, false);

        // Вкладки по центру
        Category[] cats = Category.values();
        for (int i = 0; i < cats.length; i++) {
            int x = tabX(i);
            int w = textRenderer.getWidth(cats[i].title);
            boolean sel = cats[i] == selected && query.isEmpty();
            boolean hov = inside(mx, my, x - 6, tabY - 3, w + 12, 16);
            c.drawText(textRenderer, cats[i].title, x, tabY, sel ? 0xFFFFFFFF : (hov ? 0xFFD1D5DB : DIM), false);
            if (sel) c.fill(x, tabY + 11, x + w, tabY + 12, accent());
        }
        c.fill(listX, listY - 6, listX + listW, listY - 5, 0xFF1A1A21);

        // Список
        hoverDesc = null;
        List<Entry> list = entries();
        int total = list.isEmpty() ? 0 : list.get(list.size() - 1).y + list.get(list.size() - 1).h;
        scroll = Math.max(0, Math.min(scroll, Math.max(0, total - listH)));
        c.enableScissor(listX, listY, listX + listW, listY + listH);
        if (list.isEmpty()) c.drawText(textRenderer, "Здесь пока пусто", listX, listY + 4, DIM, false);
        for (Entry e : list) {
            int y = listY + e.y - (int) scroll;
            if (y + e.h < listY || y > listY + listH) continue;
            boolean hov = inside(mx, my, listX, y, listW, e.h) && my >= listY && my < listY + listH;
            Module m = e.module;
            int lx = listX + e.indent;
            int lw = listW - e.indent - 4;

            if (e.header) {
                int on = 0;
                for (Module cm : UmbraMod.MODULES.getModules()) if (isInterface(cm) && cm.isEnabled()) on++;
                interfaceAnim += ((interfaceOpen ? 1f : 0f) - interfaceAnim) * 0.3f;
                rr(c, lx, y, lw, e.h, hov ? 0x26FFFFFF : 0x14FFFFFF);
                rr(c, lx, y + 4, 2, e.h - 8, ACCENT2);
                c.drawText(textRenderer, "Interface", lx + 9, y + 6, 0xFFFFFFFF, false);
                String info = on + "/" + INTERFACE.length;
                c.drawText(textRenderer, info, lx + lw - 24 - textRenderer.getWidth(info), y + 6, DIM, false);
                c.drawText(textRenderer, interfaceOpen ? "v" : ">", lx + lw - 12, y + 6, ACCENT2, false);
            } else if (e.setting == null && !e.modeRow) {
                boolean on = m.isEnabled();
                float a = animate(m, on);
                int bg = lerpColor(hov ? 0x1EFFFFFF : 0x12FFFFFF, hov ? com.example.umbra.Theme.tint(0x40) : com.example.umbra.Theme.tint(0x30), a);
                rr(c, lx, y, lw, e.h, bg);
                if (a > 0.02f) rr(c, lx, y + 4, 2, e.h - 8, lerpColor(com.example.umbra.Theme.tint(0x00), accent(), a));
                c.drawText(textRenderer, m.getName(), lx + 9, y + 6, lerpColor(0xFFD1D5DB, 0xFFFFFFFF, a), false);
                if (hov) hoverDesc = m.getDescription();
                if (bindingModule == m) {
                    c.drawText(textRenderer, "[нажми клавишу]", lx + 14 + textRenderer.getWidth(m.getName()), y + 6, 0xFFFACC15, false);
                } else if (m.key != GLFW.GLFW_KEY_UNKNOWN) {
                    String bind = "[" + InputUtil.fromKeyCode(m.key, 0).getLocalizedText().getString() + "]";
                    c.drawText(textRenderer, bind, lx + 14 + textRenderer.getWidth(m.getName()), y + 6, ACCENT2, false);
                }
                int sx = lx + lw - 28;
                if (expandable(m)) {
                    c.drawText(textRenderer, expanded.contains(m) ? "v" : "...", sx - 18, y + 6, DIM, false);
                }
                drawSwitch(c, sx, y + 5, a);
            } else {
                String name = e.modeRow ? "Mode" : e.setting.name;
                String value = e.modeRow ? m.getModeName() : e.setting.value();
                if (hov) rr(c, lx + 8, y, lw - 8, e.h, 0x14FFFFFF);
                c.fill(lx + 4, y, lx + 5, y + e.h, 0xFF2A2A33);
                c.drawText(textRenderer, name, lx + 14, y + 4, DIM, false);
                int vw = textRenderer.getWidth(value);
                int vx = lx + lw - 10 - vw;
                c.drawText(textRenderer, value, vx, y + 4, 0xFFF3F4F6, false);
                c.drawText(textRenderer, "<", vx - 10, y + 4, hov ? accent() : DIM, false);
                c.drawText(textRenderer, ">", vx + vw + 4, y + 4, hov ? accent() : DIM, false);
            }
        }
        c.disableScissor();

        // Полоса прокрутки
        if (total > listH) {
            int trackX = listX + listW + 6;
            c.fill(trackX, listY, trackX + 2, listY + listH, 0x22FFFFFF);
            int thumbH = Math.max(12, listH * listH / total);
            int thumbY = listY + (int) ((listH - thumbH) * (scroll / (total - listH)));
            rr(c, trackX, thumbY, 2, thumbH, accent());
        }

        // Нижняя строка
        int by = py + ph - 22;
        boolean hh = inside(mx, my, listX, by, 100, 16);
        c.drawText(textRenderer, "Позиции HUD", listX + 2, by + 4, hh ? accent() : DIM, false);
        String bottom = hoverDesc != null ? hoverDesc : "ПКМ: настройки · СКМ: клавиша · Esc";
        int bw = listW - 108;
        c.drawText(textRenderer, textRenderer.trimToWidth(bottom, bw), listX + 108, by + 4,
                hoverDesc != null ? 0xFFD1D5DB : DIM, false);
    }

    @Override
    public boolean mouseClicked(double mx, double my, int button) {
        layout();

        // Поле поиска
        if (inside(mx, my, searchX(), searchY, searchW(), SEARCH_H)) {
            searchFocused = true;
            bindingModule = null;
            return true;
        }
        if (button == 0 || button == 1) searchFocused = false;

        if (button == 0) {
            Category[] cats = Category.values();
            for (int i = 0; i < cats.length; i++) {
                if (inside(mx, my, tabX(i) - 6, tabY - 3, textRenderer.getWidth(cats[i].title) + 12, 16)) {
                    query = "";
                    selected = cats[i];
                    scroll = 0;
                    return true;
                }
            }
            if (inside(mx, my, listX, py + ph - 22, 100, 16)) {
                client.setScreen(new HudEditorScreen(this));
                return true;
            }
        }

        if ((button == 0 || button == 1 || button == 2) && inside(mx, my, listX, listY, listW, listH)) {
            for (Entry e : entries()) {
                int y = listY + e.y - (int) scroll;
                if (!inside(mx, my, listX, y, listW, e.h)) continue;
                Module m = e.module;
                int dir = button == 0 ? 1 : -1;
                if (button == 2) {
                    // Средняя кнопка по модулю: назначить клавишу
                    if (!e.header && e.setting == null && !e.modeRow) bindingModule = m;
                    return true;
                }
                if (e.header) {
                    interfaceOpen = !interfaceOpen;
                } else if (e.setting != null) {
                    e.setting.cycle(dir);
                    UmbraMod.MODULES.save();
                } else if (e.modeRow) {
                    int n = m.getModes().size();
                    for (int i = 0; i < (dir > 0 ? 1 : Math.max(1, n - 1)); i++) m.cycleMode();
                    UmbraMod.MODULES.save();
                } else if (button == 0) {
                    m.toggle();
                } else if (expandable(m)) {
                    if (!expanded.remove(m)) expanded.add(m);
                }
                return true;
            }
        }
        return super.mouseClicked(mx, my, button);
    }

    @Override
    public boolean mouseScrolled(double mx, double my, double horizontal, double vertical) {
        scroll -= vertical * 14;
        return true;
    }

    @Override
    public boolean keyPressed(int keyCode, int scanCode, int modifiers) {
        if (bindingModule != null) {
            if (keyCode == GLFW.GLFW_KEY_BACKSPACE || keyCode == GLFW.GLFW_KEY_DELETE) {
                UmbraMod.MODULES.setKey(bindingModule, GLFW.GLFW_KEY_UNKNOWN);
            } else if (keyCode != GLFW.GLFW_KEY_ESCAPE) {
                UmbraMod.MODULES.setKey(bindingModule, keyCode);
            }
            bindingModule = null;
            return true;
        }
        if (searchFocused) {
            if (keyCode == GLFW.GLFW_KEY_BACKSPACE) {
                if (!query.isEmpty()) query = query.substring(0, query.length() - 1);
                scroll = 0;
            } else if (keyCode == GLFW.GLFW_KEY_ESCAPE || keyCode == GLFW.GLFW_KEY_ENTER) {
                searchFocused = false;
            }
            return true;
        }
        if (keyCode == GLFW.GLFW_KEY_RIGHT_SHIFT) {
            close();
            return true;
        }
        return super.keyPressed(keyCode, scanCode, modifiers);
    }

    @Override
    public boolean charTyped(char chr, int modifiers) {
        if (searchFocused && chr >= 32 && query.length() < 20) {
            query += chr;
            scroll = 0;
            return true;
        }
        return super.charTyped(chr, modifiers);
    }

    @Override
    public boolean shouldPause() { return false; }
}
