package com.example.umbra.gui;

import com.example.umbra.UmbraMod;
import com.example.umbra.module.Arraylist;
import com.example.umbra.module.ArmorHud;
import com.example.umbra.module.Arrows;
import com.example.umbra.module.Category;
import com.example.umbra.module.Cps;
import com.example.umbra.module.Effects;
import com.example.umbra.module.Info;
import com.example.umbra.module.InventoryHud;
import com.example.umbra.module.Keystrokes;
import com.example.umbra.module.Module;
import com.example.umbra.module.TargetEsp;
import com.example.umbra.module.TargetHud;
import com.example.umbra.module.Toasts;
import com.example.umbra.module.Watermark;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.util.InputUtil;
import net.minecraft.text.Text;
import org.lwjgl.glfw.GLFW;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

/** Тёмное минималистичное меню: вкладки сверху, модули списком. ПКМ по модулю раскрывает его настройки. */
public class ClickGuiScreen extends Screen {
    private static final int BG = 0xF0090909;
    private static final int LINE = 0xFF1F1F1F;
    private static final int ROW = 0x0DFFFFFF;
    private static final int ROW_HOVER = 0x1CFFFFFF;
    private static int accent() { return com.example.umbra.Theme.accent(); }
    private static final int TEXT = 0xFFE5E7EB;
    private static final int DIM = 0xFF6B7280;

    private static final int ROW_H = 20;
    private static final int SUB_H = 15;

    /** Элементы интерфейса: прячутся в раскрывающемся пункте «Interface» во вкладке Визуалы. */
    private static final Class<?>[] INTERFACE = {
            InventoryHud.class, TargetEsp.class, TargetHud.class, Effects.class, Keystrokes.class, Info.class,
            Cps.class, ArmorHud.class, Arraylist.class, Arrows.class, Watermark.class, Toasts.class};
    private static boolean interfaceOpen = false;

    private static Category selected = Category.COMBAT;
    private static final Set<Module> expanded = new HashSet<>();
    private double scroll = 0;

    private int px, py, pw, ph, listX, listY, listW, listH;

    public ClickGuiScreen() {
        super(Text.literal("Umbra"));
    }

    private void layout() {
        pw = Math.min(width - 16, 300);
        ph = Math.min(height - 16, 250);
        px = (width - pw) / 2;
        py = (height - ph) / 2;
        listX = px + 8;
        listY = py + 44;
        listW = pw - 16;
        listH = ph - 74;
    }

    /** Одна строка списка: модуль или его настройка. */
    private static final class Entry {
        Module module;
        Module.Setting setting; // null = строка модуля или строка режима
        boolean modeRow;
        boolean header;
        int indent;
        int y, h;
    }

    private static boolean isInterface(Module m) {
        for (Class<?> k : INTERFACE) if (k.isInstance(m)) return true;
        return false;
    }

    private int addModule(List<Entry> out, Module m, int indent, int y) {
        Entry e = new Entry();
        e.module = m;
        e.indent = indent;
        e.y = y;
        e.h = ROW_H;
        out.add(e);
        y += ROW_H + 2;
        if (expanded.contains(m)) {
            for (Module.Setting st : m.getSettings()) {
                Entry se = new Entry();
                se.module = m;
                se.setting = st;
                se.indent = indent;
                se.y = y;
                se.h = SUB_H;
                out.add(se);
                y += SUB_H;
            }
            if (m.getSettings().isEmpty() && !m.getModes().isEmpty()) {
                Entry me = new Entry();
                me.module = m;
                me.modeRow = true;
                me.indent = indent;
                me.y = y;
                me.h = SUB_H;
                out.add(me);
                y += SUB_H;
            }
            y += 3;
        }
        return y;
    }

    private List<Entry> entries() {
        List<Entry> out = new ArrayList<>();
        int y = 0;
        if (selected == Category.VISUALS) {
            Entry head = new Entry();
            head.header = true;
            head.y = y;
            head.h = ROW_H;
            out.add(head);
            y += ROW_H + 2;
            if (interfaceOpen) {
                for (Class<?> k : INTERFACE) {
                    for (Module m : UmbraMod.MODULES.getModules()) {
                        if (k.isInstance(m)) y = addModule(out, m, 10, y);
                    }
                }
                y += 3;
            }
        }
        for (Module m : UmbraMod.MODULES.getModules()) {
            if (m.getCategory() != selected || isInterface(m)) continue;
            y = addModule(out, m, 0, y);
        }
        return out;
    }

    private static boolean expandable(Module m) {
        return !m.getSettings().isEmpty() || !m.getModes().isEmpty();
    }

    private static boolean inside(double mx, double my, int x, int y, int w, int h) {
        return mx >= x && mx < x + w && my >= y && my < y + h;
    }

    private int tabX(int index) {
        int x = px + 10;
        Category[] cats = Category.values();
        for (int i = 0; i < index; i++) x += textRenderer.getWidth(cats[i].title) + 14;
        return x;
    }

    // ---- Рисование ----

    private static final int ACCENT2 = 0xFF38BDF8;
    private static final java.util.Map<Module, Float> ANIM = new java.util.HashMap<>();
    private static float interfaceAnim = 0f;

    private static int lerpColor(int a, int b, float t) {
        t = Math.max(0f, Math.min(1f, t));
        int al = (int) (((a >>> 24) & 0xFF) + ((((b >>> 24) & 0xFF) - ((a >>> 24) & 0xFF)) * t));
        int r = (int) (((a >> 16) & 0xFF) + ((((b >> 16) & 0xFF) - ((a >> 16) & 0xFF)) * t));
        int g = (int) (((a >> 8) & 0xFF) + ((((b >> 8) & 0xFF) - ((a >> 8) & 0xFF)) * t));
        int bl = (int) ((a & 0xFF) + (((b & 0xFF) - (a & 0xFF)) * t));
        return (al << 24) | (r << 16) | (g << 8) | bl;
    }

    /** Прямоугольник со срезанными углами. */
    private static void rr(DrawContext c, int x, int y, int w, int h, int color) {
        c.fill(x + 1, y, x + w - 1, y + 1, color);
        c.fill(x, y + 1, x + w, y + h - 1, color);
        c.fill(x + 1, y + h - 1, x + w - 1, y + h, color);
    }

    private static float animate(Module m, boolean on) {
        float target = on ? 1f : 0f;
        float a = ANIM.getOrDefault(m, target);
        a += (target - a) * 0.3f;
        if (Math.abs(target - a) < 0.01f) a = target;
        ANIM.put(m, a);
        return a;
    }

    private void drawSwitch(DrawContext c, int x, int y, float a) {
        rr(c, x, y, 20, 10, lerpColor(0xFF2A2A33, accent(), a));
        int kx = x + 1 + Math.round(a * 10);
        rr(c, kx, y + 1, 8, 8, lerpColor(0xFF9CA3AF, 0xFFFFFFFF, a));
    }

    @Override
    public void renderBackground(DrawContext c, int mx, int my, float delta) {
        c.fillGradient(0, 0, width, height, 0xB0000000, 0xD0000000);
    }

    @Override
    public void render(DrawContext c, int mx, int my, float delta) {
        super.render(c, mx, my, delta);
        layout();

        // Мягкая тень вокруг панели
        for (int i = 6; i >= 1; i--) {
            rr(c, px - i, py - i, pw + 2 * i, ph + 2 * i, (0x0C - i) << 24);
        }
        // Панель: градиент и тонкая рамка
        c.fillGradient(px, py, px + pw, py + ph, 0xF2121218, 0xF20A0A0E);
        c.fill(px, py, px + 1, py + ph, 0xFF23232D);
        c.fill(px + pw - 1, py, px + pw, py + ph, 0xFF23232D);
        c.fill(px, py + ph - 1, px + pw, py + ph, 0xFF23232D);
        // Верхняя полоса: плавный переход двух акцентов
        for (int x = 0; x < pw; x++) {
            c.fill(px + x, py, px + x + 1, py + 2, lerpColor(accent(), ACCENT2, (float) x / pw));
        }

        // Заголовок
        c.drawText(textRenderer, "UMBRA", px + 10, py + 10, accent(), false);
        c.drawText(textRenderer, "client", px + 10 + textRenderer.getWidth("UMBRA ") , py + 10, DIM, false);
        String hint = "ПКМ — настройки";
        c.drawText(textRenderer, hint, px + pw - textRenderer.getWidth(hint) - 10, py + 10, DIM, false);

        // Вкладки-«таблетки»
        Category[] cats = Category.values();
        for (int i = 0; i < cats.length; i++) {
            int x = tabX(i);
            int w = textRenderer.getWidth(cats[i].title);
            boolean sel = cats[i] == selected;
            boolean hov = inside(mx, my, x - 5, py + 23, w + 10, 15);
            if (sel) {
                rr(c, x - 5, py + 23, w + 10, 15, com.example.umbra.Theme.tint(0x33));
                c.fill(x - 3, py + 37, x + w + 3, py + 38, accent());
            } else if (hov) {
                rr(c, x - 5, py + 23, w + 10, 15, 0x14FFFFFF);
            }
            c.drawText(textRenderer, cats[i].title, x, py + 27, sel ? 0xFFFFFFFF : (hov ? 0xFFD1D5DB : DIM), false);
        }

        // Список
        List<Entry> list = entries();
        int total = list.isEmpty() ? 0 : list.get(list.size() - 1).y + list.get(list.size() - 1).h;
        scroll = Math.max(0, Math.min(scroll, Math.max(0, total - listH)));
        c.enableScissor(listX, listY, listX + listW, listY + listH);
        if (list.isEmpty()) c.drawText(textRenderer, "Здесь пока пусто", listX, listY + 4, DIM, false);
        for (Entry e : list) {
            int y = listY + e.y - (int) scroll;
            if (y + e.h < listY || y > listY + listH) continue;
            boolean hov = inside(mx, my, listX, y, listW, e.h) && my >= listY && my < listY + listH;
            Module m = e.module;
            int lx = listX + e.indent;
            int lw = listW - e.indent - 4;

            if (e.header) {
                int on = 0;
                for (Module cm : UmbraMod.MODULES.getModules()) if (isInterface(cm) && cm.isEnabled()) on++;
                interfaceAnim += ((interfaceOpen ? 1f : 0f) - interfaceAnim) * 0.3f;
                rr(c, lx, y, lw, e.h, hov ? 0x26FFFFFF : 0x14FFFFFF);
                rr(c, lx, y + 4, 2, e.h - 8, ACCENT2);
                c.drawText(textRenderer, "Interface", lx + 9, y + 6, 0xFFFFFFFF, false);
                String info = on + "/" + INTERFACE.length;
                c.drawText(textRenderer, info, lx + lw - 24 - textRenderer.getWidth(info), y + 6, DIM, false);
                c.drawText(textRenderer, interfaceOpen ? "v" : ">", lx + lw - 12, y + 6, ACCENT2, false);
            } else if (e.setting == null && !e.modeRow) {
                boolean on = m.isEnabled();
                float a = animate(m, on);
                int bg = lerpColor(hov ? 0x1EFFFFFF : 0x12FFFFFF, hov ? com.example.umbra.Theme.tint(0x40) : com.example.umbra.Theme.tint(0x30), a);
                rr(c, lx, y, lw, e.h, bg);
                if (a > 0.02f) rr(c, lx, y + 4, 2, e.h - 8, lerpColor(com.example.umbra.Theme.tint(0x00), accent(), a));
                c.drawText(textRenderer, m.getName(), lx + 9, y + 6, lerpColor(0xFFD1D5DB, 0xFFFFFFFF, a), false);
                if (m.key != GLFW.GLFW_KEY_UNKNOWN) {
                    String bind = "[" + InputUtil.fromKeyCode(m.key, 0).getLocalizedText().getString() + "]";
                    c.drawText(textRenderer, bind, lx + 14 + textRenderer.getWidth(m.getName()), y + 6, ACCENT2, false);
                }
                int sx = lx + lw - 28;
                if (expandable(m)) {
                    c.drawText(textRenderer, expanded.contains(m) ? "v" : "...", sx - 18, y + 6, DIM, false);
                }
                drawSwitch(c, sx, y + 5, a);
            } else {
                String name = e.modeRow ? "Mode" : e.setting.name;
                String value = e.modeRow ? m.getModeName() : e.setting.value();
                if (hov) rr(c, lx + 8, y, lw - 8, e.h, 0x14FFFFFF);
                c.fill(lx + 4, y, lx + 5, y + e.h, 0xFF2A2A33);
                c.drawText(textRenderer, name, lx + 14, y + 4, DIM, false);
                int vw = textRenderer.getWidth(value);
                int vx = lx + lw - 10 - vw;
                c.drawText(textRenderer, value, vx, y + 4, 0xFFF3F4F6, false);
                c.drawText(textRenderer, "<", vx - 10, y + 4, hov ? accent() : DIM, false);
                c.drawText(textRenderer, ">", vx + vw + 4, y + 4, hov ? accent() : DIM, false);
            }
        }
        c.disableScissor();

        // Полоса прокрутки
        if (total > listH) {
            int trackX = px + pw - 5;
            c.fill(trackX, listY, trackX + 2, listY + listH, 0x22FFFFFF);
            int thumbH = Math.max(12, listH * listH / total);
            int thumbY = listY + (int) ((listH - thumbH) * (scroll / (total - listH)));
            rr(c, trackX, thumbY, 2, thumbH, accent());
        }

        // Нижняя панель
        int by = py + ph - 24;
        c.fill(px + 8, by - 3, px + pw - 8, by - 2, 0xFF23232D);
        boolean hh = inside(mx, my, px + 8, by, 100, 16);
        c.drawText(textRenderer, "Позиции HUD", px + 10, by + 4, hh ? accent() : DIM, false);
        String close = "Esc — закрыть";
        c.drawText(textRenderer, close, px + pw - textRenderer.getWidth(close) - 10, by + 4, DIM, false);
    }

    @Override
    public boolean mouseClicked(double mx, double my, int button) {
        layout();

        if (button == 0) {
            Category[] cats = Category.values();
            for (int i = 0; i < cats.length; i++) {
                if (inside(mx, my, tabX(i) - 3, py + 22, textRenderer.getWidth(cats[i].title) + 6, 17)) {
                    selected = cats[i];
                    scroll = 0;
                    return true;
                }
            }
            if (inside(mx, my, px + 8, py + ph - 24, 100, 16)) {
                client.setScreen(new HudEditorScreen(this));
                return true;
            }
        }

        if ((button == 0 || button == 1) && inside(mx, my, listX, listY, listW, listH)) {
            for (Entry e : entries()) {
                int y = listY + e.y - (int) scroll;
                if (!inside(mx, my, listX, y, listW, e.h)) continue;
                Module m = e.module;
                int dir = button == 0 ? 1 : -1;
                if (e.header) {
                    interfaceOpen = !interfaceOpen;
                } else if (e.setting != null) {
                    e.setting.cycle(dir);
                    UmbraMod.MODULES.save();
                } else if (e.modeRow) {
                    int n = m.getModes().size();
                    for (int i = 0; i < (dir > 0 ? 1 : Math.max(1, n - 1)); i++) m.cycleMode();
                    UmbraMod.MODULES.save();
                } else if (button == 0) {
                    m.toggle();
                } else if (expandable(m)) {
                    if (!expanded.remove(m)) expanded.add(m);
                }
                return true;
            }
        }
        return super.mouseClicked(mx, my, button);
    }

    @Override
    public boolean mouseScrolled(double mx, double my, double horizontal, double vertical) {
        scroll -= vertical * 14;
        return true;
    }

    @Override
    public boolean keyPressed(int keyCode, int scanCode, int modifiers) {
        if (keyCode == GLFW.GLFW_KEY_RIGHT_SHIFT) {
            close();
            return true;
        }
        return super.keyPressed(keyCode, scanCode, modifiers);
    }

    @Override
    public boolean shouldPause() { return false; }
}
