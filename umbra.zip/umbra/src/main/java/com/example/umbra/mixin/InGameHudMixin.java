package com.example.umbra.mixin;

import com.example.umbra.UmbraMod;
import com.example.umbra.module.Crosshair;
import net.minecraft.client.gui.hud.InGameHud;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(InGameHud.class)
public abstract class InGameHudMixin {
    // Crosshair: прячем обычный прицел, когда включён свой
    @Inject(method = "renderCrosshair", at = @At("HEAD"), cancellable = true, require = 0)
    private void umbra$hideCrosshair(CallbackInfo ci) {
        Crosshair c = UmbraMod.MODULES.get(Crosshair.class);
        if (c != null && c.isEnabled()) ci.cancel();
    }
}
