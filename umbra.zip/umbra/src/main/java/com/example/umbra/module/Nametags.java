package com.example.umbra.module;

import com.example.umbra.Palette;
import com.example.umbra.WorldDraw;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.util.math.Vec3d;

/** Над обычным ником игрока показывает HP, броню и расстояние. */
public class Nametags extends Module {
    private final Setting info = addSetting("Info", new String[]{"HP + Dist", "HP", "Dist"}, 0);
    private long lastTick = System.nanoTime();

    public Nametags() {
        super("Nametags", "Над ником: HP, броня и расстояние", Category.VISUALS);
    }

    @Override
    public void onTick(MinecraftClient client) { lastTick = System.nanoTime(); }

    @Override
    public void renderHud(DrawContext c) {
        MinecraftClient client = MinecraftClient.getInstance();
        if (client.player == null || client.world == null) return;
        WorldDraw cam = new WorldDraw(client, c);
        double t = Math.min(1.0, (System.nanoTime() - lastTick) / 50_000_000.0);
        for (PlayerEntity p : client.world.getPlayers()) {
            if (p == client.player || !p.isAlive()) continue;
            double dist = Math.sqrt(p.squaredDistanceTo(client.player));
            if (dist > 64) continue;
            double x = p.prevX + (p.getX() - p.prevX) * t;
            double y = p.prevY + (p.getY() - p.prevY) * t;
            double z = p.prevZ + (p.getZ() - p.prevZ) * t;
            double[] pt = cam.project(new Vec3d(x, y + p.getHeight() + 0.95, z));
            if (pt == null) continue;

            float hp = p.getHealth();
            float max = Math.max(1f, p.getMaxHealth());
            int hpColor = Palette.mix(0xFFFF4D4D, 0xFF4ADE80, hp / max);
            String hpText = String.format("%.1f HP", hp);
            String armor = "A" + p.getArmor();
            String dst = (int) dist + "m";
            String text = switch (info.index) {
                case 1 -> hpText + "  " + armor;
                case 2 -> dst;
                default -> hpText + "  " + armor + "  " + dst;
            };
            int w = client.textRenderer.getWidth(text) + 8;
            int x0 = (int) Math.round(pt[0]) - w / 2;
            int y0 = (int) Math.round(pt[1]) - 6;
            c.fill(x0, y0, x0 + w, y0 + 12, 0x99000000);
            c.fill(x0, y0 + 11, x0 + Math.round(w * Math.min(1f, hp / max)), y0 + 12, hpColor);
            c.drawTextWithShadow(client.textRenderer, text, x0 + 4, y0 + 2, 0xFFF1F5F9);
        }
    }
}
