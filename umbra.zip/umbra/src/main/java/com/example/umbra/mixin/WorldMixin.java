package com.example.umbra.mixin;

import com.example.umbra.UmbraMod;
import com.example.umbra.module.TimeChanger;
import net.minecraft.client.world.ClientWorld;
import net.minecraft.world.World;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(World.class)
public abstract class WorldMixin {
    private TimeChanger umbra$active() {
        if (!((Object) this instanceof ClientWorld)) return null;
        TimeChanger t = UmbraMod.MODULES.get(TimeChanger.class);
        return (t != null && t.isEnabled()) ? t : null;
    }

    @Inject(method = "getTimeOfDay", at = @At("HEAD"), cancellable = true, require = 0)
    private void umbra$time(CallbackInfoReturnable<Long> cir) {
        TimeChanger t = umbra$active();
        if (t != null) cir.setReturnValue(t.time());
    }

    @Inject(method = "getSkyAngle", at = @At("HEAD"), cancellable = true, require = 0)
    private void umbra$sky(CallbackInfoReturnable<Float> cir) {
        TimeChanger t = umbra$active();
        if (t != null) cir.setReturnValue(t.skyAngle());
    }
}
