package com.example.umbra.module;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.option.CloudRenderMode;
import net.minecraft.client.option.GameOptions;
import net.minecraft.client.option.GraphicsMode;

/**
 * Снижает нагрузку настройками игры. Выключил модуль: все настройки возвращаются как были.
 *  Light: дальность 12, облака и тени существ выключены.
 *  Medium: дальность 8, быстрая графика.
 *  Max: дальность 6, существа рисуются ближе.
 */
public class Optimize extends Module {
    private final Setting preset = addSetting("Preset", new String[]{"Light", "Medium", "Max"}, 1);

    private boolean saved;
    private int oView, oSim;
    private double oEntity;
    private GraphicsMode oGraphics;
    private CloudRenderMode oClouds;
    private boolean oShadows;
    private int appliedPreset = -1;

    public Optimize() {
        super("Optimize", "Больше FPS: снижает нагрузку настройками игры", Category.MISC);
    }

    @Override
    public void onEnable() {
        MinecraftClient c = MinecraftClient.getInstance();
        if (c.options == null) return;
        GameOptions o = c.options;
        oView = o.getViewDistance().getValue();
        oSim = o.getSimulationDistance().getValue();
        oEntity = o.getEntityDistanceScaling().getValue();
        oGraphics = o.getGraphicsMode().getValue();
        oClouds = o.getCloudRenderMode().getValue();
        oShadows = o.getEntityShadows().getValue();
        saved = true;
        appliedPreset = -1;
    }

    @Override
    public void onTick(MinecraftClient client) {
        if (!saved || client.options == null || appliedPreset == preset.index) return;
        appliedPreset = preset.index;
        GameOptions o = client.options;
        int level = preset.index;
        o.getViewDistance().setValue(Math.min(oView, level == 0 ? 12 : level == 1 ? 8 : 6));
        o.getSimulationDistance().setValue(Math.min(oSim, level == 0 ? 10 : level == 1 ? 8 : 5));
        o.getEntityDistanceScaling().setValue(level == 2 ? 0.5 : level == 1 ? 0.75 : oEntity);
        o.getCloudRenderMode().setValue(CloudRenderMode.OFF);
        o.getEntityShadows().setValue(false);
        if (level >= 1) o.getGraphicsMode().setValue(GraphicsMode.FAST);
        else o.getGraphicsMode().setValue(oGraphics);
    }

    @Override
    public void onDisable() {
        MinecraftClient c = MinecraftClient.getInstance();
        if (c.options == null || !saved) return;
        GameOptions o = c.options;
        o.getViewDistance().setValue(oView);
        o.getSimulationDistance().setValue(oSim);
        o.getEntityDistanceScaling().setValue(oEntity);
        o.getGraphicsMode().setValue(oGraphics);
        o.getCloudRenderMode().setValue(oClouds);
        o.getEntityShadows().setValue(oShadows);
        saved = false;
        appliedPreset = -1;
    }
}
