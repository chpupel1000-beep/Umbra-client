package com.example.umbra.module;

import com.example.umbra.Palette;

/** Общий акцентный цвет клиента. Включён: используется выбранный цвет, выключен: фиолетовый. */
public class ThemeSettings extends Module {
    private final Setting color = addSetting("Color", Palette.NAMES, 7);

    public ThemeSettings() {
        super("Theme", "Акцентный цвет меню, Arraylist и уведомлений", Category.VISUALS);
    }

    public int rgb() { return Palette.RGB[color.index]; }

    public int colorIndex() { return color.index; }

    public void setColorIndex(int i) { color.index = Math.max(0, Math.min(i, Palette.RGB.length - 1)); }
}
