package com.example.umbra.module;

import com.example.umbra.HudLayout;
import com.example.umbra.Theme;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.network.PlayerListEntry;

import java.time.LocalTime;
import java.time.format.DateTimeFormatter;

/** Надпись Umbra с FPS, пингом и временем. */
public class Watermark extends Module {
    private static final DateTimeFormatter TIME = DateTimeFormatter.ofPattern("HH:mm");

    public Watermark() {
        super("Watermark", "Umbra | FPS | пинг | время", Category.VISUALS);
    }

    @Override
    public void renderHud(DrawContext c) {
        MinecraftClient client = MinecraftClient.getInstance();
        if (client.player == null) return;
        int ping = 0;
        if (client.getNetworkHandler() != null) {
            PlayerListEntry e = client.getNetworkHandler().getPlayerListEntry(client.player.getUuid());
            if (e != null) ping = e.getLatency();
        }
        int x = HudLayout.x(HudLayout.WATERMARK, c.getScaledWindowWidth(), HudLayout.WATERMARK.w);
        int y = HudLayout.y(HudLayout.WATERMARK, c.getScaledWindowHeight(), HudLayout.WATERMARK.h);
        c.fill(x, y, x + HudLayout.WATERMARK.w, y + HudLayout.WATERMARK.h, 0x99000000);
        c.fill(x, y, x + 2, y + HudLayout.WATERMARK.h, Theme.accent());
        c.drawTextWithShadow(client.textRenderer, "Umbra", x + 7, y + 4, Theme.accent());
        String rest = client.getCurrentFps() + " fps | " + ping + " ms | " + LocalTime.now().format(TIME);
        c.drawTextWithShadow(client.textRenderer, rest, x + 12 + client.textRenderer.getWidth("Umbra"), y + 4, 0xFFE5E7EB);
    }
}
